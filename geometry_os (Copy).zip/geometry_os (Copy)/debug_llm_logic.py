import sqlite3
import os

class MockCortex:
    def __init__(self, model_name, db_path):
        self.model_name = model_name
        self.db_path = db_path
    
    def fetch(self):
        print(f"   🕸️  Querying Nexus for Neural Weights...")
        try:
            abs_path = os.path.abspath(self.db_path)
            print(f"   🔎 DB Path: {abs_path}")
            print(f"   🔎 Querying ID: '{self.model_name}'")
            
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.execute("SELECT type, content, metadata FROM nodes WHERE id=?", (self.model_name,))
            row = cursor.fetchone()
            
            if row:
                print("   ✅ FOUND inside Class!")
                print(dict(row))
            else:
                print("   ❌ NOT FOUND inside Class.")
        except Exception as e:
            print(f"   ⚠️ ERROR: {e}")

cortex = MockCortex("qwen2.5-coder-7b-instruct-q4_k_m", "/home/jericho/zion/projects/geometry_os/geometry_os/ctrm_llm_os.db")
cortex.fetch()
