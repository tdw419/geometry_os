
def calculate_factorial(n)
    if n == 0:
        return 1
    return n * calculate_factorial(n - 1)

result = calculate_factorial(5)
print(f"5! = {result}")
