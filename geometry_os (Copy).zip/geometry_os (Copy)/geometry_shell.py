#!/usr/bin/env python3
"""
geometry_shell.py - The Neural Interface of Geometry OS
Binds the Holographic Cortex (LLM) to the System State (Nexus/FS).
"""

import os
import sys
import json
import time
import subprocess
import argparse
from datetime import datetime

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), "src"))
sys.path.append(os.path.dirname(__file__)) # For holographic_llm

try:
    from holographic_llm import HolographicCortex
except ImportError:
    print("❌ Critical: holographic_llm.py not found.")
    sys.exit(1)

import requests

class HolographicClient:
    """Client for the Holographic API"""
    def __init__(self, base_url="http://localhost:8000"):
        self.base_url = base_url
        self.model_name = "Remote Cortex"
        
    def think(self, prompt):
        try:
            # Call the Custom Cortex Endpoint
            payload = {
                "prompt": prompt,
                "max_tokens": 1000
            }
            # Use /api/think as defined in holographic_api.py
            response = requests.post(f"{self.base_url}/api/think", json=payload, timeout=120)
            if response.status_code == 200:
                data = response.json()
                # Check response structure
                if "data" in data:
                    return data["data"]
                return str(data)
            else:
                return f"[API Error: {response.status_code}]"
        except Exception as e:
            return f"[Connection Error: {e}]"

class GeometryOSShell:
    def __init__(self, model_name, db_path):
        # 1. Try to connect to existing Daemon
        try:
            print("📡 Scanning for active Cortex Daemon...")
            resp = requests.get("http://localhost:8000/api/status", timeout=2)
            if resp.status_code == 200:
                print("✅ Daemon Found. Attaching to shared consciousness.")
                self.cortex = HolographicClient()
                self.cwd = os.getcwd()
                self.context_window = []
                return
        except:
            print("⚠️  No Daemon found. Loading local brain (High RAM Usage)...")

        # 2. Fallback to local loading
        self.cortex = HolographicCortex(model_name, db_path)
        self.cwd = os.getcwd()
        self.context_window = []
        
    def get_system_state(self):
        """Capture the current physiological state of the OS"""
        files = os.listdir(self.cwd)[:10] # Show top 10 files
        timestamp = datetime.now().isoformat()
        return f"""
[SYSTEM CONTEXT]
TIME: {timestamp}
CWD: {self.cwd}
FILES: {', '.join(files)}...
USER: Jericho
OS_GOAL: "Autonomous Evolution"
"""

    def parse_action(self, response):
        """Allow the LLM to execute shell commands"""
        if "EXEC:" in response:
            try:
                cmd = response.split("EXEC:")[1].split("\n")[0].strip()
                print(f"   ⚙️  Executing: {cmd}")
                result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
                return f"[EXECUTION_RESULT]\n{result.decode('utf-8')[:500]}"
            except Exception as e:
                return f"[EXECUTION_ERROR] {str(e)}"
        return None

    def repl(self):
        print(f"\n🌌 \033[1;35mGeometry OS Neural Shell\033[0m")
        print(f"   \033[1;30mConnected to Nexus + {self.cortex.model_name}\033[0m")
        
        while True:
            try:
                user_input = input("\n\033[1;36mGeometry>\033[0m ")
                if user_input.lower() in ['exit', 'quit']:
                    break
                
                # 1. Perceive
                # 1. Perceive
                system_state = self.get_system_state()
                prompt = f"{system_state}\nHere is the user request: {user_input}"
                
                print("\033[1;33mProcessing...\033[0m", end="\r")
                
                # 2. Think
                response = self.cortex.think(prompt)
                
                # 3. Act (Execute any embedded commands)
                action_result = self.parse_action(response)
                
                # 4. Export synthetic data if requested
                if getattr(self, "synthetic_export_path", None):
                    try:
                        import json, os
                        export_path = self.synthetic_export_path
                        # Ensure directory exists
                        os.makedirs(os.path.dirname(export_path) or ".", exist_ok=True)
                        with open(export_path, "a", encoding="utf-8") as f:
                            json.dump({"prompt": prompt, "response": response}, f)
                            f.write("\n")
                    except Exception as e:
                        print(f"⚠️  Failed to export synthetic data: {e}")
                
                print(f"\033[1;32m{response}\033[0m")
                
                # If the OS took an action, show the result
                if action_result:
                    print(f"\n\033[1;30m{action_result}\033[0m")
                    
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"Error: {e}")

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

def auto_activate_venv():
    """Auto-detect and activate virtual environment"""
    # Look for env in current dir
    venv_path = os.path.join(PROJECT_ROOT, "geometry_os_env")
    if os.path.exists(venv_path):
        import sys
        # Check if we are running from this venv
        if sys.prefix != venv_path:
            print(f"🔄 Switching to Neural Environment: {venv_path}")
            python_bin = os.path.join(venv_path, "bin", "python3")
            if os.path.exists(python_bin):
                # Re-execute with the correct interpreter
                os.execv(python_bin, [python_bin] + sys.argv)

if __name__ == "__main__":
    auto_activate_venv()
    
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True, help="Model Node Name (e.g. DeepSeek-Coder-V2...)")
    parser.add_argument("--db", default="ghost_daemon_knowledge.db")
    parser.add_argument(
        "--export-synthetic",
        type=str,
        default=None,
        help="If set, each (prompt, response) pair will be appended as a JSON line to the given file.",
    )
    args = parser.parse_args()
    
    shell = GeometryOSShell(args.model, args.db)
    # Attach the export path to the shell so the REPL can write data
    shell.synthetic_export_path = args.export_synthetic
    shell.repl()
