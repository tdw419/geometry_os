#!/usr/bin/env python3
"""
Flask application that serves a lightweight web UI for Geometry OS.
It provides shortcuts to core OS features: status, telemetry, diagnostics, and a launch button for the existing dashboard.
Additionally it serves a 3‑D visualizer built with Three.js.
"""
import os, subprocess
from flask import Flask, render_template, redirect, send_from_directory, request

# Configure Flask – static files will be served from the 'static' subdirectory
app = Flask(__name__, static_folder='static')

# ---------------------------------------------------------------------
# Core routes
# ---------------------------------------------------------------------
@app.route('/')
def home():
    """Render the main control‑panel page."""
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    """Redirect to the existing holographic dashboard (GPU‑accelerated)."""
    return redirect('http://localhost:8000')

@app.route('/status')
def status():
    """Placeholder status page – can be extended to proxy /api/status."""
    return render_template('status.html')

# ---------------------------------------------------------------------
# 3‑D visualizer
# ---------------------------------------------------------------------
@app.route('/visualizer')
def visualizer():
    """Render a page with a rotating wire‑frame sphere (Three.js)."""
    return render_template('visualizer.html')

@app.route('/shell', methods=['GET', 'POST'])
def shell():
    """Simple GUI to run geometry_shell.py with custom arguments.
    GET: render form. POST: execute command and show output.
    """
    if request.method == 'POST':
        model = request.form.get('model', '').strip()
        db = request.form.get('db', '').strip()
        cmd = ['python3', 'geometry_shell.py']
        if model:
            cmd.extend(['--model', model])
        if db:
            cmd.extend(['--db', db])
        try:
            result = subprocess.run(cmd, cwd=os.path.abspath(os.path.join(os.path.dirname(__file__), '..')),
                             capture_output=True, text=True, timeout=30)
            output = result.stdout + '\n' + result.stderr
        except Exception as e:
            output = f'Error executing command: {e}'
        return render_template('shell.html', output=output, model=model, db=db)
    # GET – show empty form
    return render_template('shell.html', output='', model='', db='')

# Serve static assets (e.g., custom JS or CSS) from the static folder
@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(os.path.join(app.root_path, 'static'), filename)

# ---------------------------------------------------------------------
if __name__ == '__main__':
    # Run on port 5000 – the launcher script will start this.
    app.run(host='0.0.0.0', port=5000, debug=False)
