import asyncio
import aiohttp
import sys
import time
import json

async def monitor():
    url = "http://localhost:8000/api/telemetry"
    print(f"📡 Connecting to Holographic Cortex at {url}...")
    print("   (Press Ctrl+C to stop)")
    print("-" * 50)
    
    last_thought = ""
    
    async with aiohttp.ClientSession() as session:
        while True:
            try:
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        # Extract metrics
                        status = data.get("status", "unknown")
                        current_thought = data.get("current_thought", "")
                        
                        # Only print if thought changed
                        if current_thought and current_thought != last_thought:
                            print(f"\n🧠 [THOUGHT STREAM] {time.strftime('%H:%M:%S')}")
                            print(f"   {current_thought}")
                            last_thought = current_thought
                            
                        # Show heartbeat dot
                        print(f"\r💓 {status.upper()} | CPU: {data.get('cpu_usage', 0)}% | RAM: {data.get('memory_usage', 0)}%", end="")
                        
            except Exception as e:
                print(f"\r⚠️  Connection lost: {e}", end="")
            
            await asyncio.sleep(1)

if __name__ == "__main__":
    try:
        asyncio.run(monitor())
    except KeyboardInterrupt:
        print("\n👋 Disconnected.")
