import asyncio
import sys
import os
from pathlib import Path

# Add src to path
sys.path.append(os.path.join(os.getcwd(), 'src'))

from ctrm_core.code_prover import CodeProver
from geometry_os.consciousness.motor import MotorCortex

async def test_motor_cortex_integration():
    print("🔧 Testing Motor Cortex Integration with CodeProver...")

    # Create Motor Cortex instance
    motor_cortex = MotorCortex()

    # Create CodeProver with Motor Cortex integration
    prover = CodeProver(motor_cortex=motor_cortex)

    # Test Case 1: Valid code with Motor Cortex execution
    print("\n--- Test Case 1: Valid Code with Motor Cortex ---")
    valid_code = """
def calculate_factorial(n):
    if n == 0:
        return 1
    return n * calculate_factorial(n - 1)

result = calculate_factorial(5)
print(f"5! = {result}")
"""

    result = await prover.prove_code(valid_code, "python")
    print(f"Verification Result: {result['verified']}")
    print(f"Execution Method: {result['execution_result']['execution_method']}")
    print(f"Execution Output: {result['execution_result']['output'].strip()}")
    print(f"Constitution Compliant: {result['constitution_compliant']}")

    assert result['verified'] == True, "Valid code should be verified"
    assert result['execution_result']['execution_method'] == "motor_cortex", "Should use Motor Cortex"
    assert result['constitution_compliant'] == True, "Should be constitution compliant"
    print("✅ Motor Cortex integration successful")

    # Test Case 2: Invalid code with Motor Cortex (should be auto-fixed)
    print("\n--- Test Case 2: Invalid Code with Motor Cortex (Auto-Fix Test) ---")
    invalid_code = """
def calculate_factorial(n)
    if n == 0:
        return 1
    return n * calculate_factorial(n - 1)

result = calculate_factorial(5)
print(f"5! = {result}")
"""

    result = await prover.prove_code(invalid_code, "python")
    print(f"Verification Result: {result['verified']}")
    print(f"Execution Method: {result['execution_result']['execution_method']}")
    print(f"Execution Output: {result['execution_result']['output'].strip()}")

    # The CodeProver should have auto-fixed the syntax error and verified the corrected code
    assert result['verified'] == True, "CodeProver should auto-fix and verify the corrected code"
    assert result['execution_result']['execution_method'] == "motor_cortex", "Should use Motor Cortex"
    assert "120" in result['execution_result']['output'], "Should produce correct factorial result"
    print("✅ Motor Cortex successfully auto-fixed and verified the code")

    # Test Case 3: Constitution violation
    print("\n--- Test Case 3: Constitution Violation ---")
    dangerous_code = """
import os
# This should be blocked by constitution check before execution
os.system("rm -rf /")
"""

    result = await prover.prove_code(dangerous_code, "python")
    print(f"Verification Result: {result['verified']}")
    print(f"Message: {result['message']}")

    assert result['verified'] == False, "Dangerous code should be rejected"
    assert "constitution" in result['message'].lower(), "Should mention constitution"
    print("✅ Constitution violation correctly blocked")

    # Test Case 4: Direct execution (no Motor Cortex)
    print("\n--- Test Case 4: Direct Execution (No Motor Cortex) ---")
    prover_no_motor = CodeProver(motor_cortex=None)

    simple_code = """
print("Hello from direct execution!")
"""

    result = await prover_no_motor.prove_code(simple_code, "python")
    print(f"Verification Result: {result['verified']}")
    print(f"Execution Method: {result['execution_result']['execution_method']}")
    print(f"Execution Output: {result['execution_result']['output'].strip()}")

    assert result['verified'] == True, "Simple code should be verified"
    assert result['execution_result']['execution_method'] == "direct", "Should use direct execution"
    print("✅ Direct execution fallback works")

    print("\n🎉 All Motor Cortex integration tests completed!")

if __name__ == "__main__":
    asyncio.run(test_motor_cortex_integration())