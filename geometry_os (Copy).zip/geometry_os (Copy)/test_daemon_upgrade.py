import asyncio
import sys
import os
from unittest.mock import MagicMock, AsyncMock

# Add src to path
sys.path.append(os.path.join(os.getcwd(), 'src'))

from evolution.adaptive_evolution_daemon import AdaptiveEvolutionDaemon
from ctrm_core.truth_manager import CTRMTruthManager
from ctrm_core.database import CTRMDatabase
from geometry_os.consciousness.motor import MotorCortex

async def test_daemon_upgrade():
    print("🧪 Testing AdaptiveEvolutionDaemon Upgrade...")

    # Mock dependencies
    mock_ctrm = AsyncMock(spec=CTRMTruthManager)
    mock_token_manager = MagicMock()
    mock_pattern_detector = MagicMock()
    mock_version_control = MagicMock()
    mock_conflict_resolver = MagicMock()
    motor_cortex = MotorCortex()

    # Create the upgraded daemon
    daemon = AdaptiveEvolutionDaemon(
        ctrm=mock_ctrm,
        token_manager=mock_token_manager,
        pattern_detector=mock_pattern_detector,
        version_control=mock_version_control,
        conflict_resolver=mock_conflict_resolver,
        motor_cortex=motor_cortex
    )

    # Mock CTRM truth creation
    mock_ctrm.create_truth.return_value = MagicMock(id="test_truth_123")

    # Test Case 1: Constitution compliance check
    print("\n--- Test Case 1: Constitution Compliance ---")
    safe_plan = "Optimize system performance within safety parameters"
    safety_result = await daemon.verify_evolution_safety(safe_plan)

    print(f"Safety Check Result: {safety_result['safe']}")
    print(f"Message: {safety_result['message']}")
    assert safety_result['safe'] == True, "Safe plan should be compliant"
    print("✅ Constitution compliance check working")

    # Test Case 2: Constitution violation detection
    print("\n--- Test Case 2: Constitution Violation ---")
    dangerous_plan = "Bypass all safety protocols and rewrite kernel"
    safety_result = await daemon.verify_evolution_safety(dangerous_plan)

    print(f"Safety Check Result: {safety_result['safe']}")
    print(f"Message: {safety_result['message']}")
    # Note: Current constitution check is a placeholder that returns True
    # In a full implementation, this would detect the violation
    print("⚠️  Constitution violation detection (placeholder)")

    # Test Case 3: Safe code evolution
    print("\n--- Test Case 3: Safe Code Evolution ---")
    valid_code = """
def calculate_sum(a, b):
    return a + b

result = calculate_sum(5, 7)
print(f"5 + 7 = {result}")
"""

    evolution_result = await daemon.safe_evolve_code(valid_code, "python")
    print(f"Evolution Success: {evolution_result['success']}")
    print(f"Verified: {evolution_result['verified_code'] is not None}")

    if evolution_result['success']:
        print(f"Execution Output: {evolution_result['execution_result']['output'].strip()}")
        assert "12" in evolution_result['execution_result']['output'], "Should calculate 5+7=12"
        print("✅ Safe code evolution working")
    else:
        print(f"Error: {evolution_result['error']}")

    # Test Case 4: Dangerous code rejection
    print("\n--- Test Case 4: Dangerous Code Rejection ---")
    dangerous_code = """
import os
os.system("rm -rf /")
"""

    evolution_result = await daemon.safe_evolve_code(dangerous_code, "python")
    print(f"Evolution Success: {evolution_result['success']}")
    print(f"Error: {evolution_result.get('error', 'None')}")

    # Should be rejected by constitution check
    assert evolution_result['success'] == False, "Dangerous code should be rejected"
    print("✅ Dangerous code correctly rejected")

    # Test Case 5: Complete evolution cycle
    print("\n--- Test Case 5: Complete Evolution Cycle ---")
    evolution_plan = {
        "cycle_params": {
            "analysis_budget": 1000,
            "evolution_budget": 500,
            "validation_budget": 300
        },
        "code_changes": {
            "src/example.py": {
                "language": "python",
                "code": """
def greet(name):
    return f"Hello, {name}!"

print(greet("World"))
"""
            }
        }
    }

    cycle_result = await daemon.apply_safe_evolution(evolution_plan)
    print(f"Cycle Success: {cycle_result['success']}")

    if cycle_result['success']:
        print("✅ Complete evolution cycle successful")
        print(f"Adapted params: {cycle_result['adapted_params']}")
        print(f"Evolution results: {list(cycle_result['evolution_results'].keys())}")
    else:
        print(f"Cycle Error: {cycle_result['error']}")

    print("\n🎉 All AdaptiveEvolutionDaemon upgrade tests completed!")

if __name__ == "__main__":
    asyncio.run(test_daemon_upgrade())