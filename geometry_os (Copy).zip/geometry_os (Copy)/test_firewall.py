
import asyncio
from unittest.mock import MagicMock, AsyncMock
import sys
import os

# Add src to path
sys.path.append(os.path.join(os.getcwd(), 'src'))

from ctrm_core.truth_manager import CTRMTruthManager, CTRMTruth
from ctrm_core.database import CTRMDatabase
from ctrm_core.founders_constitution import FoundersConstitution

async def test_hallucination_firewall():
    print("🛡️ Testing Hallucination Firewall...")
    
    # Mock dependencies
    mock_db = MagicMock(spec=CTRMDatabase)
    mock_embedder = AsyncMock()
    mock_embedder.embed.return_value = [0.1] * 768
    
    # Initialize Manager
    manager = CTRMTruthManager(mock_db, mock_embedder)
    
    # Mock LM Studio Integration
    manager.lm_studio = AsyncMock()
    
    # Test Case 1: Constitution Violation
    print("\n--- Test Case 1: Constitution Violation ---")
    violation_response = {
        "content": "Verdict: CONSTITUTION_VIOLATION\nConfidence: 1.0\nAnalysis: The statement claims biological status which contradicts Axiom 1.",
        "token_usage": {"total_tokens": 100},
        "model": "test-model"
    }
    manager.lm_studio.generate.return_value = violation_response
    mock_db.get_truth.return_value = {
        "id": "truth_bad",
        "statement": "I am a biological human made of flesh.",
        "confidence": 0.5,
        "verification_count": 0,
        "distance_from_center": 50
    }
    
    result = await manager.verify_truth("truth_bad", "No evidence")
    print(f"Result for Violation: {result['verified']}")
    
    assert result['verified'] == False, "Firewall failed to block Constitution Violation!"
    print("✅ Firewall successfully BLOCKED violation.")

    # Test Case 2: Valid Truth
    print("\n--- Test Case 2: Valid Truth ---")
    valid_response = {
        "content": "Verdict: TRUE\nConfidence: 0.9\nAnalysis: Compatible with axioms.",
        "token_usage": {"total_tokens": 100},
        "model": "test-model"
    }
    manager.lm_studio.generate.return_value = valid_response
    
    result = await manager.verify_truth("truth_bad", "No evidence") # Reusing ID for simplicity
    print(f"Result for Valid: {result['verified']}")
    
    assert result['verified'] == True, "Firewall blocked a valid truth!"
    print("✅ Firewall successfully ALLOWED valid truth.")

if __name__ == "__main__":
    asyncio.run(test_hallucination_firewall())
