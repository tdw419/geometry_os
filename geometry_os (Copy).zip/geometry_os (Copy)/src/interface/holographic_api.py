#!/usr/bin/env python3
"""
Holographic API Server for Geometry OS
Real-time hardware telemetry visualization backend
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn
import threading
import time
from datetime import datetime

# Local imports
from hardware.hal import HardwareAbstractionLayer, create_hal, HALMonitor
from hardware.drivers.neural_driver_base import DriverState

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class HolographicAPI:
    """Holographic API Server for real-time hardware visualization"""

    def __init__(self, hal: HardwareAbstractionLayer = None, cortex = None):
        """Initialize the holographic API"""
        self.hal = hal or create_hal()
        self.cortex = cortex
        self.monitor = HALMonitor(self.hal)
        self.app = FastAPI(
            title="Geometry OS Holographic API",
            description="Real-time hardware telemetry visualization for Geometry OS",
            version="1.0.0",
            docs_url="/api/docs",
            redoc_url="/api/redoc"
        )
        
        # ... (CORS config remains same) ...
        self._configure_cors()
        self._setup_routes()
        self._start_background_monitoring()

    def _configure_cors(self):
        """Configure CORS middleware"""
        from fastapi.middleware.cors import CORSMiddleware
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _setup_routes(self):
        """Set up API routes"""
        
        from pydantic import BaseModel
        class ThinkRequest(BaseModel):
            prompt: str
            max_tokens: int = 1000

        @self.app.post("/api/think")
        async def think(request: ThinkRequest):
            """Execute a thought process via the Cortex Manager"""
            if not self.cortex:
                raise HTTPException(status_code=503, detail="Cortex Manager not connected")
            try:
                # self.cortex is now HolographicIntegration
                # It has an async complete() method
                response = await self.cortex.complete(prompt=request.prompt, max_tokens=request.max_tokens)
                # Response is Dict with 'choices'
                if isinstance(response, dict) and "choices" in response:
                    return {"status": "success", "data": response["choices"][0]["text"]}
                return {"status": "success", "data": str(response)}
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/api/status")
        async def get_status():
            """Get overall system status"""
            try:
                status = self.hal.get_operational_status()
                health = self.monitor.check_health()

                return {
                    "status": "success",
                    "data": {
                        "hal_state": status,
                        "health": health,
                        "timestamp": datetime.now().isoformat()
                    }
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/api/system")
        async def get_system_info():
            """Get system hardware summary"""
            try:
                summary = self.hal.get_system_summary()
                return {
                    "status": "success",
                    "data": summary
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/api/devices")
        async def get_all_devices():
            """Get all hardware devices and their status"""
            try:
                devices = []
                for device_id, driver in self.hal.get_all_drivers().items():
                    devices.append({
                        "device_id": device_id,
                        "name": driver.get_component_info().get("name", "Unknown"),
                        "type": driver.get_component_info().get("component_type", "unknown"),
                        "state": driver.get_state().name,
                        "is_operational": driver.is_operational(),
                        "capabilities": [cap.name for cap in driver.get_capabilities()],
                        "status": driver.read_status() if driver.is_operational() else None
                    })

                return {
                    "status": "success",
                    "data": {
                        "devices": devices,
                        "total_devices": len(devices),
                        "operational_devices": sum(1 for d in devices if d["is_operational"])
                    }
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/api/device/{device_id}")
        async def get_device_status(device_id: str):
            """Get detailed status for a specific device"""
            try:
                driver = self.hal.get_driver(device_id)
                if not driver:
                    raise HTTPException(status_code=404, detail="Device not found")

                return {
                    "status": "success",
                    "data": {
                        "device_id": device_id,
                        "name": driver.get_component_info().get("name", "Unknown"),
                        "type": driver.get_component_info().get("component_type", "unknown"),
                        "state": driver.get_state().name,
                        "is_operational": driver.is_operational(),
                        "capabilities": [cap.name for cap in driver.get_capabilities()],
                        "status": driver.read_status() if driver.is_operational() else None,
                        "health": driver.get_health_status() if hasattr(driver, 'get_health_status') else None
                    }
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/api/telemetry")
        async def get_telemetry():
            """Get real-time telemetry data for all devices"""
            try:
                telemetry = {
                    "timestamp": datetime.now().isoformat(),
                    "devices": []
                }

                for device_id, driver in self.hal.get_all_drivers().items():
                    if driver.is_operational():
                        try:
                            device_telemetry = {
                                "device_id": device_id,
                                "name": driver.get_component_info().get("name", "Unknown"),
                                "type": driver.get_component_info().get("component_type", "unknown"),
                                "state": driver.get_state().name,
                                "status": driver.read_status()
                            }

                            # Add specialized telemetry based on device type
                            component_type = driver.get_component_info().get("component_type", "")
                            if component_type == "cpu" and hasattr(driver, 'get_cpu_usage'):
                                device_telemetry["cpu_usage"] = driver.get_cpu_usage()
                            elif component_type == "memory" and hasattr(driver, 'get_memory_stats'):
                                device_telemetry["memory_stats"] = driver.get_memory_stats()
                            elif component_type == "disk" and hasattr(driver, 'get_disk_stats'):
                                device_telemetry["disk_stats"] = driver.get_disk_stats()
                            elif component_type == "network" and hasattr(driver, 'get_current_stats'):
                                device_telemetry["network_stats"] = driver.get_current_stats().to_dict()

                            telemetry["devices"].append(device_telemetry)
                        except Exception as e:
                            logger.error(f"Error getting telemetry for {device_id}: {str(e)}")
                            continue

                return {
                    "status": "success",
                    "data": telemetry
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/api/health")
        async def get_health_report():
            """Get detailed health report"""
            try:
                report = self.monitor.get_detailed_health_report()
                return {
                    "status": "success",
                    "data": report
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/api/refresh")
        async def refresh_hardware():
            """Refresh hardware discovery"""
            try:
                result = self.hal.refresh_hardware()
                return {
                    "status": "success",
                    "data": result
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

    def _start_background_monitoring(self):
        """Start background thread for continuous monitoring"""
        def monitoring_loop():
            while True:
                try:
                    # Refresh hardware periodically
                    self.hal.refresh_hardware()

                    # Log health status
                    health = self.monitor.check_health()
                    if health['issues']:
                        logger.warning(f"HAL health issues detected: {health['issues']}")
                    else:
                        logger.info("HAL operating normally")

                    # Sleep for 30 seconds between checks
                    time.sleep(30)
                except Exception as e:
                    logger.error(f"Error in background monitoring: {str(e)}")
                    time.sleep(10)  # Wait before retrying

        # Start monitoring thread
        self.monitoring_thread = threading.Thread(
            target=monitoring_loop,
            daemon=True,
            name="HALMonitoringThread"
        )
        self.monitoring_thread.start()

    def run(self, host: str = "0.0.0.0", port: int = 8000):
        """Run the holographic API server"""
        try:
            logger.info(f"Starting Holographic API server on {host}:{port}")
            logger.info(f"HAL State: {self.hal.get_state()}")
            logger.info(f"Operational Devices: {self.hal.get_operational_status()['operational_devices']}")

            # Mount static files if they exist
            ui_dir = "src/ui/dashboard"
            if os.path.exists(ui_dir):
                self.app.mount("/", StaticFiles(directory=ui_dir, html=True), name="static")
                logger.info(f"Mounted static files from {ui_dir}")
            else:
                logger.info("No UI directory found - running API only mode")

            # Run the server
            uvicorn.run(
                self.app,
                host=host,
                port=port,
                log_level="info",
                access_log=True
            )

        except Exception as e:
            logger.error(f"Failed to start holographic API: {str(e)}")
            raise

    def shutdown(self):
        """Shutdown the holographic API"""
        try:
            logger.info("Shutting down Holographic API")
            self.hal.shutdown()
            logger.info("Holographic API shutdown complete")
        except Exception as e:
            logger.error(f"Error shutting down holographic API: {str(e)}")

def create_holographic_api() -> HolographicAPI:
    """Create and return a holographic API instance"""
    return HolographicAPI()

def main():
    """Main entry point for holographic API"""
    try:
        logger.info("🚀 Starting Geometry OS Holographic Visualization System")

        # Create and run the holographic API
        api = create_holographic_api()
        api.run(host="0.0.0.0", port=8000)

    except KeyboardInterrupt:
        logger.info("🛑 Holographic API stopped by user")
    except Exception as e:
        logger.error(f"💥 Fatal error in holographic API: {str(e)}")
        raise

if __name__ == '__main__':
    main()