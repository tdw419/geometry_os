import asyncio
import os
import sys
import json
from typing import Dict, Any, Optional

# Add root to path for holographic_llm import context
sys.path.append(os.path.join(os.path.dirname(__file__), "../.."))

try:
    from holographic_llm import HolographicCortex
except ImportError:
    # Use fallback if not found in root (depending on run context)
    pass

class HolographicIntegration:
    """
    Drop-in replacement for LMStudioIntegration.
    Uses local GGUF models via HolographicCortex instead of HTTP API.
    """
    def __init__(self, model_name: str = "phi-4", db_path: str = "ghost_daemon_knowledge.db"):
        self.model_name = model_name
        self._cortex = None
        self.db_path = db_path
        self.context_length = 16384 # Phi-4 default

    def _ensure_cortex(self):
        """Lazy load the model on first use"""
        if not self._cortex:
            print(f"🧠 [HOLO] Initializing Internal Organ: {self.model_name}")
            try:
                self._cortex = HolographicCortex(self.model_name, db_path=self.db_path)
            except Exception as e:
                print(f"❌ [HOLO] Failed to mount cortex: {e}")
                raise

    async def generate(self, model: str, prompt: str, max_tokens: int = 2000, stop: list = None, temperature: float = 0.7) -> Dict[str, Any]:
        """
        Async wrapper for the synchronous local inference.
        Matches the signature of LMStudioIntegration.generate()
        """
        self._ensure_cortex()
        
        # Run cpu-bound inference in a separate thread to keep the daemon event loop alive
        result_text = await asyncio.to_thread(
            self._cortex.think,
            prompt
        )

        # Return in the format the Daemon expects (API-like structure)
        return {
            "choices": [
                {"text": result_text}
            ],
            "content": result_text, # Helper for some parts of code
            "usage": {
                "total_tokens": len(prompt) // 4 + len(result_text) // 4 # Approximate
            }
        }

    async def complete(self, prompt: str, max_tokens: int = 2000, temperature: float = 0.7, stop: list = None, **kwargs) -> Dict[str, Any]:
        """Alias for generate to maintain compatibility with LMStudioIntegration interface"""
        return await self.generate(
            model=self.model_name,
            prompt=prompt,
            max_tokens=max_tokens,
            stop=stop,
            temperature=temperature
        )
        
    async def list_models(self):
        """Mock list models (returning our internal one)"""
        return [{"id": self.model_name, "context_length": self.context_length}]

    async def get_loaded_model(self):
        return self.model_name

    def get_model_context_length(self, model: str) -> int:
        """Return the context length of the model."""
        if "phi-4" in self.model_name.lower():
            return 16384
        if "qwen" in self.model_name.lower():
            return 32768
        return self.context_length

    async def generate_embedding(self, model: str, input_text: str) -> list[float]:
        """Generate vector embedding for text using local cortex."""
        self._ensure_cortex()
        
        # Check if cortex has embedding capability
        if hasattr(self._cortex, 'llm') and hasattr(self._cortex.llm, 'create_embedding'):
            # Run in thread to avoid blocking loop
            embedding_response = await asyncio.to_thread(
                self._cortex.llm.create_embedding,
                input_text
            )
            # Response format: {'data': [{'embedding': [...]}], ...}
            if embedding_response and 'data' in embedding_response:
                return embedding_response['data'][0]['embedding']
        
        print("⚠️ [HOLO] Cortex missing embedding capability. Returning zero vector.")
        return [0.0] * 768 # Fallback zero vector

    def unload_cortex(self):
        """Unload the current model to free memory."""
        if self._cortex:
            print("🧠 [HOLO] Unloading Holographic Cortex...")
            # Force deletion of the Llama object to free VRAM/RAM
            try:
                if hasattr(self._cortex, 'llm'):
                    del self._cortex.llm
                del self._cortex
            except Exception as e:
                print(f"⚠️ Error unloading cortex: {e}")
            
            self._cortex = None
            import gc
            gc.collect()
            print("🧠 [HOLO] Cortex Unloaded.")

    def reload_cortex(self, model_name: str = None):
        """Hot-reload the cortex, potentially with a new model."""
        if model_name:
            self.model_name = model_name
        
        print(f"🧠 [HOLO] Reloading Cortex: {self.model_name}...")
        self.unload_cortex()
        self._ensure_cortex()
        print("🧠 [HOLO] Cortex Reloaded Successfully.")
