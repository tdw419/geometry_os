import sys
import traceback
import inspect
import asyncio
import json
import time
from datetime import datetime
from typing import Callable, Any, Dict

class SelfHealingRuntime:
    """
    The Autonomic Nervous System for Geometry OS.
    Wraps execution to catch crashes, analyze them, and patch code on the fly.
    """

    def __init__(self, ctrm, lm_studio, config_manager):
        self.ctrm = ctrm
        self.lm_studio = lm_studio
        self.config_manager = config_manager
        self.heal_attempts = 0
        
        # Load limits from config or use safe defaults
        if self.config_manager:
            self.max_heal_attempts_per_hour = self.config_manager.get("self_healing.max_attempts_per_hour", 5)
        else:
            self.max_heal_attempts_per_hour = 5
            
        self.last_reset = time.time()

    async def execute_with_immunity(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute a function with an accumulated immunity layer.
        If it fails, attempt to heal and retry.
        """
        try:
            if inspect.iscoroutinefunction(func):
                return await func(*args, **kwargs)
            else:
                return func(*args, **kwargs)
        except Exception as e:
            print(f"💥 Runtime Exception in {func.__name__}: {e}")
            
            # Attempt active healing
            healed = await self._attempt_heal(func, e)
            
            if healed:
                print(f"🩹 Function {func.__name__} patched. Retrying...")
                # Recursively retry (with guard against infinite loops via heal_attempts)
                return await self.execute_with_immunity(func, *args, **kwargs)
            else:
                # If cannot heal, re-raise to maintain system integrity signals
                raise e

    async def _attempt_heal(self, func: Callable, error: Exception) -> bool:
        """
        The Core Repair Logic:
        1. Read source
        2. Analyze error
        3. Generative fix
        4. Apply patch
        """
        # Reset counter if hour has passed
        if time.time() - self.last_reset > 3600:
            self.heal_attempts = 0
            self.last_reset = time.time()
            
        self.heal_attempts += 1
        
        # Check active limits
        if self.heal_attempts > self.max_heal_attempts_per_hour: 
            print(f"⚠️ Healing exhausted ({self.heal_attempts}/{self.max_heal_attempts_per_hour}). System Critical.")
            return False

        try:
            # 1. Capture Context
            src_code = inspect.getsource(func)
            src_file = inspect.getsourcefile(func)
            tb = traceback.format_exc()
            
            print(f"🚑 Dispatching Emergency Surgeon to {src_file}")

            # 2. Consult the Cortex (LLM)
            model = await self.lm_studio.get_loaded_model()
            if not model:
                return False

            prompt = f"""
            CRITICAL SYSTEM FAILURE DETECTED.
            File: {src_file}
            Function: {func.__name__}
            Error: {str(error)}
            Traceback:
            {tb}

            Source Code:
            ```python
            {src_code}
            ```

            TASK: Return the FIXED Python source code for this function ONLY. 
            Do not explain. Just provide the code block.
            Fix the Logic/Syntax error that caused the crash.
            """

            # 3. Generate Patch
            response = await self.lm_studio.generate(model, prompt, temperature=0.2)
            fixed_code = self._extract_code(response["content"])
            
            if not fixed_code:
                return False

            # 4. Verify Patch Safety
            if not self._verify_patch_safety(fixed_code):
                print("⚠️ Surgeon Refusal: Generated patch failed safety checks.")
                return False

            # 5. Apply Patch (Dangerous - requires high trust)
            self._hot_patch_file(src_file, src_code, fixed_code)
            
            # Log the localized trauma and repair event
            await self.ctrm.create_truth(
                statement=f"Self-healed exception in {func.__name__}: {str(error)}",
                confidence=0.95,
                context=json.dumps({
                    "file": src_file,
                    "error": str(error),
                    "patch_size": len(fixed_code)
                }),
                metadata={"category": "system_immunity"}
            )
            
            return True

        except Exception as heal_err:
            print(f"💀 Surgeon died on the table: {heal_err}")
            return False

    def _verify_patch_safety(self, code: str) -> bool:
        """
        Verify the generated patch is at least syntactically valid python.
        Future: Run unit tests / static analysis.
        """
        try:
            import ast
            ast.parse(code)
            # Basic heuristic: ensure it's not empty and looks like a function
            if "def " not in code:
                return False
            return True
        except SyntaxError:
            print("❌ Patch contained SyntaxError")
            return False
        except Exception:
            return False

        except Exception as heal_err:
            print(f"💀 Surgeon died on the table: {heal_err}")
            return False

    def _extract_code(self, text: str) -> str:
        """Extract code from markdown block"""
        if "```python" in text:
            return text.split("```python")[1].split("```")[0].strip()
        if "```" in text:
            return text.split("```")[1].split("```")[0].strip()
        return text.strip()

    def _hot_patch_file(self, filepath: str, old_code: str, new_code: str):
        """
        Surgically replaces the old function text with new text in the file.
        """
        with open(filepath, 'r') as f:
            content = f.read()
            
        # Be careful with indentation and whitespace matching
        # transform old_code to match file indentation if `inspect` stripped it?
        # inspect.getsource usually preserves indentation relative to file context
        # but let's try strict find-replace first.
        
        if old_code.strip() in content:
             # This is risky if exact whitespace match fails, 
             # but `inspect.getsource` is usually accurate.
             # We might need to normalize whitespace.
             content = content.replace(old_code.strip(), new_code.strip())
        else:
             # Fallback: simple text similarity or line replacement
             # For MVP, we abort if strict match fails to avoid corruption
             print("⚠️ Patch failed: Source mismatch (indentation?)")
             return

        with open(filepath, 'w') as f:
            f.write(content)
        print(f"✅ Patch applied to disk: {filepath}")
