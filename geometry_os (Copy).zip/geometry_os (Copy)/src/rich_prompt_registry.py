#!/usr/bin/env python3
"""
rich_prompt_registry.py – Extensive, context-aware prompt templates for Geometry OS.

This module provides a diverse set of prompt templates categorized by OS function.
It goes beyond simple "verb object" patterns to include:
- Technical diagnostic queries
- Architectural reasoning requests
- Holographic visualization commands
- Neural evolution directives
- Filesystem & vector-store operations

Usage:
    from rich_prompt_registry import get_random_prompts
    prompts = get_random_prompts(count=50)
"""

import random
from typing import List, Dict

# ----------------------------------------------------------------------
# CATEGORY 1: HOLOGRAPHIC DIAGNOSTICS & VISUALIZATION
# ----------------------------------------------------------------------
HOLO_TEMPLATES = [
    "Visualize the real-time telemetry for the {component} subsystem.",
    "Generate a holographic overlay showing the current {metric} state.",
    "Project the dependency graph for the {module} module.",
    "Render a 3D heatmap of the {resource} utilization across all cores.",
    "Display the quantum coherence status of the {layer} layer.",
    "Show me the active neural pathways connecting to the {hub}.",
    "Visualize the memory fragmentation in the {heap} region.",
]

HOLO_VARS = {
    "component": ["motor cortex", "visual cortex", "nexus bridge", "driver layer", "kernel core"],
    "metric": ["CPU thermal", "memory pressure", "holographic stability", "vector alignment"],
    "module": ["holo_diagnostic", "neural_driver_base", "geometry_fs", "vector_dna"],
    "resource": ["GPU VRAM", "system RAM", "I/O bandwidth", "neural token"],
    "layer": ["physical", "network", "application", "holographic"],
    "hub": ["Nexus Prime", "Ghost Daemon", "Sensor Array"],
    "heap": ["shared", "local", "quantum"],
}

# ----------------------------------------------------------------------
# CATEGORY 2: SYSTEM ARCHITECTURE & EVOLUTION
# ----------------------------------------------------------------------
ARCH_TEMPLATES = [
    "Analyze the structural integrity of the {system} architecture.",
    "Propose an optimization strategy for the {bottleneck}.",
    "Evaluate the readiness of the system for {milestone}.",
    "Compare the current state of {component} with the {reference} spec.",
    "Draft a refactoring plan to decouple {module_a} from {module_b}.",
    "Assess the risk of integrating the {new_feature} into the kernel.",
    "Simulate the impact of increasing the {parameter} by {percentage}.",
]

ARCH_VARS = {
    "system": ["Geometry OS", "CTRM Kernel", "Ghost Shell", "Vector VFS"],
    "bottleneck": ["message bus", "rendering pipeline", "database lock", "context switch"],
    "milestone": ["Phase 11 (Consciousness)", "Phase 12 (Quantum)", "Autonomous Agency"],
    "component": ["holographic_llm", "synthetic_daemon", "boot_sys"],
    "reference": ["Founders Constitution", "Holographic Blueprints", "Legacy Fossil Record"],
    "module_a": ["ui_render_loop", "neural_driver", "kernel_monitor"],
    "module_b": ["disk_io", "network_stack", "logging_subsystem"],
    "new_feature": ["hyper-dimensional indexing", "quantum-entangled caching"],
    "parameter": ["context window", "learning rate", "quantization level"],
    "percentage": ["10%", "50%", "200%"],
}

# ----------------------------------------------------------------------
# CATEGORY 3: FILE SYSTEM & VECTOR OPERATIONS
# ----------------------------------------------------------------------
FS_TEMPLATES = [
    "Scan the vector database for anomalies in the {table} table.",
    "Index the latest {file_type} files in the {directory} directory.",
    "Retrieve the semantic embeddings related to '{concept}'.",
    "Verify the cryptographic signature of the {critical_file}.",
    "Optimize the storage layout for {data_type} blobs.",
    "Check for dangling references in the {fs_layer} filesystem.",
    "Migrate the {legacy_data} to the new {storage_format}.",
]

FS_VARS = {
    "table": ["user_interactions", "long_term_memory", "vector_dna", "system_logs"],
    "file_type": ["Python", "Markdown", "JSON", "GGUF"],
    "directory": ["/src/system", "/data/vectors", "/geometry_os/docs"],
    "concept": ["autonomy", "self-healing", "recursive improvement", "user privacy"],
    "critical_file": ["boot_sys.py", "founders_constitution.py", "hal.py"],
    "data_type": ["holographic", "vector", "binary", "text"],
    "fs_layer": ["GeometryFS", "GhostVFS", "NexusMount"],
    "legacy_data": ["fossil records", "old logs", "deprecated configs"],
    "storage_format": ["Parquet", "Arrow", "QuantumBlob"],
}

# ----------------------------------------------------------------------
# CATEGORY 4: CONTEXTUAL & "META" REQUESTS
# ----------------------------------------------------------------------
META_TEMPLATES = [
    "Explain the purpose of the currently open file: {filename}.",
    "Based on the system context, what should be the next development step?",
    "Summarize the recent changes in the {directory} directory.",
    "Identify any potential security vulnerabilities in the current codebase.",
    "Generate a unit test for the {function_name} function.",
    "How does the {module} contribute to the goal of '{goal}'?",
]

META_VARS = {
    "filename": ["holo_diagnostic.py", "synthetic_daemon.py", "geometry_shell.py"],
    "directory": ["src/hardware", "src/evolution", "src/interface"],
    "function_name": ["think", "generate_rich_prompts", "visualize_status", "evolve_kernel"],
    "module": ["prompt_generator", "holographic_cortex", "nexus_prime"],
    "goal": ["Autonomous Evolution", "Seamless Integration", "Quantum Supremacy"],
}

# ----------------------------------------------------------------------
# PROMPT GENERATION LOGIC
# ----------------------------------------------------------------------

ALL_CATEGORIES = [
    (HOLO_TEMPLATES, HOLO_VARS),
    (ARCH_TEMPLATES, ARCH_VARS),
    (FS_TEMPLATES, FS_VARS),
    (META_TEMPLATES, META_VARS),
]

def _fill_template(template: str, variables: Dict[str, List[str]]) -> str:
    """Recursively fill a template string with random choices from variables."""
    result = template
    for key, choices in variables.items():
        placeholder = "{" + key + "}"
        if placeholder in result:
            result = result.replace(placeholder, random.choice(choices), 1)
    return result

def get_rich_prompts(count: int = 100) -> List[str]:
    """Generate a diverse set of rich, context-aware prompts."""
    prompts = []
    
    # Ensure even distribution across categories initially
    per_category = count // len(ALL_CATEGORIES)
    remainder = count % len(ALL_CATEGORIES)
    
    for templates, variables in ALL_CATEGORIES:
        for _ in range(per_category):
            tmpl = random.choice(templates)
            prompts.append(_fill_template(tmpl, variables))
            
    # Fill any remainder with random choices
    for _ in range(remainder):
        templates, variables = random.choice(ALL_CATEGORIES)
        tmpl = random.choice(templates)
        prompts.append(_fill_template(tmpl, variables))
        
    random.shuffle(prompts)
    return prompts

if __name__ == "__main__":
    # Demo output
    print(f"--- Generated 10 Rich Prompts ---")
    for p in get_rich_prompts(10):
        print(f"• {p}")
