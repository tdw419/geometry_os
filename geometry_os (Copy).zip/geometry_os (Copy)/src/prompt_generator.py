#!/usr/bin/env python3
"""
prompt_generator.py – utilities for creating richer, OS‑aware prompts.

The goal is to produce diverse, realistic user‑requests that exercise the
Geometry OS API surface.  The generator combines:

* **Static templates** – e.g. "Please {action} the {target} status."
* **Dynamic adjectives / qualifiers** – to vary tone and complexity.
* **System‑state placeholders** – the daemon will later prepend the
  `[SYSTEM CONTEXT]` block (cwd, files, timestamp, etc.).
* **Optional LLM‑driven expansion** – if a model is available, we can ask it
  to rewrite a simple request into a more elaborate one.

Usage example (from synthetic_daemon.py):

```python
from prompt_generator import generate_rich_prompts
prompts = generate_rich_prompts(count=200)
```

The function returns a list of plain‑text user requests (no system‑context).
"""

import random
from typing import List

# ----------------------------------------------------------------------
# Basic word pools – feel free to extend them as the OS evolves.
# ----------------------------------------------------------------------
ACTIONS = [
    "visualize",
    "diagnose",
    "optimize",
    "inspect",
    "reset",
    "query",
    "monitor",
    "profile",
    "summarize",
    "export",
]

TARGETS = [
    "process status",
    "memory usage",
    "network traffic",
    "disk health",
    "holographic pipeline",
    "sensor array",
    "execution queue",
    "system logs",
    "resource allocation",
    "module dependencies",
]

ADJECTIVES = [
    "current",
    "latest",
    "detailed",
    "brief",
    "comprehensive",
    "high‑level",
    "low‑level",
]

# ----------------------------------------------------------------------
def _random_template() -> str:
    """Pick a random template and fill it with random words.
    Returns a plain user request string, e.g. "Please visualize the current
    memory usage."
    """
    action = random.choice(ACTIONS)
    target = random.choice(TARGETS)
    adj = random.choice(ADJECTIVES)
    # Simple grammar – prepend "Please" for politeness.
    return f"Please {action} the {adj} {target}."

# ----------------------------------------------------------------------
def generate_rich_prompts(count: int = 100) -> List[str]:
    """Generate *count* diverse prompts.

    The function currently uses deterministic randomness (seeded with system time).
    For reproducibility you can set ``random.seed(<int>)`` before calling.
    """
    prompts = []
    for _ in range(count):
        prompts.append(_random_template())
    return prompts

# ----------------------------------------------------------------------
# Optional LLM‑driven expansion (requires a running Holographic daemon).
# ----------------------------------------------------------------------
def expand_prompts_via_llm(prompts: List[str], model_name: str = "qwen2.5-coder-7b-instruct-q4_k_m") -> List[str]:
    """Send each prompt to the remote Holographic API and ask the model to
    rewrite it in a more elaborate style.

    This function is *optional* – synthetic_daemon can call it if the user
    passes ``--use-llm``.
    """
    import requests
    expanded = []
    for p in prompts:
        try:
            payload = {"prompt": f"Rewrite the following request in a more detailed, technical style:\n{p}", "max_tokens": 200}
            resp = requests.post("http://localhost:8000/api/think", json=payload, timeout=30)
            if resp.status_code == 200:
                data = resp.json()
                expanded.append(data.get("data", p))
            else:
                expanded.append(p)
        except Exception:
            expanded.append(p)
    return expanded

# ----------------------------------------------------------------------
if __name__ == "__main__":
    # Simple demo when run directly.
    for line in generate_rich_prompts(5):
        print(line)
"""
