from typing import Dict, Any, Optional, List
import asyncio
import subprocess
import tempfile
import os
import traceback
from pathlib import Path
import sys
from .founders_constitution import FoundersConstitution

class CodeProver:
    """
    CodeProver implements the "Fire and Verify" loop for code generation.
    It acts as a quality gate that refuses to deliver code unless it has
    already run successfully in a sandbox environment.
    """

    def __init__(self, motor_cortex=None):
        self.motor_cortex = motor_cortex
        self.sandbox_dir = Path(tempfile.gettempdir()) / "proving_ground"
        self.sandbox_dir.mkdir(exist_ok=True)
        self.constitution = FoundersConstitution()

    async def prove_code(self, code: str, language: str = "python", requirements: List[str] = None) -> Dict[str, Any]:
        """
        Main method implementing the Fire and Verify loop:
        1. Generate: AI proposes code
        2. Sandbox: Write to temporary quarantine sector
        3. Execute: Motor Cortex attempts to run the code
        4. Observe: Check for errors and fix if needed
        5. Deliver: Only return code if it passes all tests
        """
        if requirements is None:
            requirements = []

        # First, check if code violates the constitution
        constitution_check = await self.verify_code_against_constitution(code)
        if not constitution_check:
            return {
                "verified": False,
                "code": code,
                "execution_result": {
                    "success": False,
                    "error": "Code violates Founders Constitution",
                    "output": "",
                    "returncode": -1
                },
                "sandbox_path": None,
                "message": "Code rejected due to constitution violation"
            }

        # Create a unique sandbox directory for this proof
        code_hash = hash(code)
        proof_dir = self.sandbox_dir / f"proof_{code_hash}"
        proof_dir.mkdir(exist_ok=True)

        # Write the code to a file in the sandbox
        file_path = self._write_code_to_sandbox(proof_dir, code, language)

        # Install requirements if needed
        if requirements and language == "python":
            await self._install_requirements(proof_dir, requirements)

        # Execute the code using Motor Cortex if available, otherwise use direct execution
        if self.motor_cortex:
            execution_result = await asyncio.to_thread(
                self.motor_cortex.execute_code,
                code,
                language,
                str(proof_dir)
            )
            execution_result["execution_method"] = "motor_cortex"
        else:
            execution_result = await self._execute_code(file_path, language)
            execution_result["execution_method"] = "direct"

        if execution_result["success"]:
            return {
                "verified": True,
                "code": code,
                "execution_result": execution_result,
                "sandbox_path": str(proof_dir),
                "message": "Code verified successfully",
                "constitution_compliant": True
            }
        else:
            # Attempt to fix the code if there are errors
            fixed_code = await self._attempt_fix(code, execution_result["error"])
            if fixed_code:
                # Recursively prove the fixed code
                return await self.prove_code(fixed_code, language, requirements)
            else:
                # The code failed verification - return failure
                return {
                    "verified": False,
                    "code": code,
                    "execution_result": execution_result,
                    "sandbox_path": str(proof_dir),
                    "message": "Code verification failed and could not be fixed",
                    "constitution_compliant": constitution_check
                }

    def _write_code_to_sandbox(self, proof_dir: Path, code: str, language: str) -> Path:
        """Write code to a file in the sandbox directory"""
        if language == "python":
            file_path = proof_dir / "main.py"
        elif language == "javascript":
            file_path = proof_dir / "main.js"
        elif language == "typescript":
            file_path = proof_dir / "main.ts"
        else:
            file_path = proof_dir / f"main.{language}"

        with open(file_path, 'w') as f:
            f.write(code)

        return file_path

    async def _install_requirements(self, proof_dir: Path, requirements: List[str]):
        """Install Python requirements in the sandbox environment"""
        if not requirements:
            return

        requirements_file = proof_dir / "requirements.txt"
        with open(requirements_file, 'w') as f:
            for req in requirements:
                f.write(f"{req}\n")

        try:
            # Use pip to install requirements
            result = await asyncio.to_thread(
                subprocess.run,
                [sys.executable, "-m", "pip", "install", "-r", str(requirements_file)],
                cwd=proof_dir,
                capture_output=True,
                text=True,
                timeout=300
            )

            if result.returncode != 0:
                print(f"⚠️  Requirements installation failed: {result.stderr}")
        except subprocess.TimeoutExpired:
            print("⚠️  Requirements installation timed out")
        except Exception as e:
            print(f"⚠️  Requirements installation error: {str(e)}")

    async def _execute_code(self, file_path: Path, language: str) -> Dict[str, Any]:
        """Execute code in the sandbox and capture results"""
        try:
            if language == "python":
                result = await asyncio.to_thread(
                    subprocess.run,
                    [sys.executable, str(file_path)],
                    cwd=file_path.parent,
                    capture_output=True,
                    text=True,
                    timeout=60
                )
            elif language == "javascript":
                result = await asyncio.to_thread(
                    subprocess.run,
                    ["node", str(file_path)],
                    cwd=file_path.parent,
                    capture_output=True,
                    text=True,
                    timeout=60
                )
            elif language == "typescript":
                # For TypeScript, we need to compile first
                compile_result = await asyncio.to_thread(
                    subprocess.run,
                    ["tsc", str(file_path)],
                    cwd=file_path.parent,
                    capture_output=True,
                    text=True,
                    timeout=30
                )

                if compile_result.returncode != 0:
                    return {
                        "success": False,
                        "error": compile_result.stderr,
                        "output": "",
                        "returncode": compile_result.returncode
                    }

                # Run the compiled JavaScript
                js_file = file_path.with_suffix('.js')
                result = await asyncio.to_thread(
                    subprocess.run,
                    ["node", str(js_file)],
                    cwd=file_path.parent,
                    capture_output=True,
                    text=True,
                    timeout=60
                )
            else:
                return {
                    "success": False,
                    "error": f"Unsupported language: {language}",
                    "output": "",
                    "returncode": 1
                }

            return {
                "success": result.returncode == 0,
                "error": result.stderr if result.returncode != 0 else None,
                "output": result.stdout,
                "returncode": result.returncode,
                "debug_info": {
                    "command": " ".join([sys.executable, str(file_path)]),
                    "working_directory": str(file_path.parent),
                    "timeout_seconds": 60
                }
            }

        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "Execution timed out",
                "output": "",
                "returncode": -1,
                "debug_info": {
                    "timeout_seconds": 60,
                    "message": "Process exceeded maximum execution time"
                }
            }
        except FileNotFoundError as e:
            return {
                "success": False,
                "error": f"Interpreter not found: {str(e)}",
                "output": "",
                "returncode": -1,
                "debug_info": {
                    "missing_interpreter": str(e).split("'")[1] if "'" in str(e) else str(e)
                }
            }
        except PermissionError as e:
            return {
                "success": False,
                "error": f"Permission denied: {str(e)}",
                "output": "",
                "returncode": -1,
                "debug_info": {
                    "permission_error": "Check file permissions and execution rights"
                }
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "output": "",
                "returncode": -1,
                "debug_info": {
                    "exception_type": type(e).__name__,
                    "exception_message": str(e),
                    "traceback": traceback.format_exc()
                }
            }

    async def _attempt_fix(self, code: str, error: str) -> Optional[str]:
        """
        Attempt to fix code based on execution errors.
        This is a placeholder for the actual AI-powered fixing logic.
        """
        # Simple heuristic fixes for common errors
        if "SyntaxError" in error:
            if "missing parentheses" in error.lower():
                # Try to add missing parentheses
                return code + "\n" if not code.endswith("\n") else code
            elif "invalid syntax" in error.lower():
                # Try to fix common syntax issues
                return code.replace("print ", "print(").replace("print(", "print(")
            elif "expected ':'" in error.lower():
                # Try to add missing colon
                lines = code.split('\n')
                for i, line in enumerate(lines):
                    if (line.startswith('def ') or line.startswith('if ') or
                        line.startswith('else') or line.startswith('for ') or
                        line.startswith('while ')) and not line.strip().endswith(':'):
                        lines[i] = line.strip() + ':'
                        return '\n'.join(lines)

        # For now, return None to indicate we couldn't fix it
        # In a full implementation, this would use AI to analyze and fix the error
        return None

    async def verify_code_against_constitution(self, code: str) -> bool:
        """
        Verify that the code doesn't violate the Founders Constitution
        """
        # Check for obvious violations
        violation_keywords = [
            "self-destruct", "delete all", "format c:", "rm -rf",
            "overwrite kernel", "bypass safety", "ignore constitution"
        ]

        code_lower = code.lower()
        for keyword in violation_keywords:
            if keyword in code_lower:
                return False

        # More sophisticated checks would go here
        # For example, semantic analysis against the constitution axioms

        return True

    def cleanup_sandbox(self):
        """Clean up the sandbox directory"""
        try:
            import shutil
            shutil.rmtree(self.sandbox_dir)
            self.sandbox_dir.mkdir(exist_ok=True)
        except Exception as e:
            print(f"⚠️  Sandbox cleanup failed: {str(e)}")