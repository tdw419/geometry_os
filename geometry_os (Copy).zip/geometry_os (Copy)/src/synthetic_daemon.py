#!/usr/bin/env python3
"""
synthetic_daemon.py – headless daemon to generate synthetic Q&A data for Geometry OS.

Usage example:
    python3 geometry_os/src/synthetic_daemon.py \
        --model "qwen2.5-coder-7b-instruct-q4_k_m" \
        --db "data/ctrm_llm_os.db" \
        --output data/synthetic_os.jsonl \
        --max-rows 500 \
        --sleep 0.5

The daemon:
  1. Connects to the supplied SQLite DB.
  2. Tries to read a table named `user_interactions` (or `interactions`).
     Expected columns: `prompt` (text). If the table does not exist, it falls back to
     generating random prompts with Faker.
  3. For each prompt it builds a minimal system‑state context (cwd, timestamp).
  4. Calls the LLM (local HolographicCortex or remote via HolographicClient) to
     obtain a response.
  5. Appends a JSON line ``{"prompt": <prompt>, "response": <response>}`` to the
     output file.
  6. Optionally sleeps between iterations to avoid hammering the model.

The script re‑uses the same export‑logic that was added to `geometry_shell.py` so the
output format is identical.
"""

import argparse
import json
import os
import sqlite3
import sys
import time
from datetime import datetime

# ------------------------------------------------------------
# Helper: load the appropriate Cortex (local or remote)
# ------------------------------------------------------------
import sys
import os
# Ensure the repository root (which contains holographic_llm.py) is on PYTHONPATH
repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if repo_root not in sys.path:
    sys.path.append(repo_root)

try:
    from holographic_llm import HolographicCortex
except ImportError:
    print("❌ Critical: holographic_llm.py not found.")
    sys.exit(1)

# Optional remote client (same class used by geometry_shell)
import requests


class HolographicClient:
    """Thin wrapper for the remote Holographic API (same as geometry_shell)."""

    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.model_name = "Remote Cortex"

    def think(self, prompt: str) -> str:
        try:
            payload = {"prompt": prompt, "max_tokens": 1000}
            resp = requests.post(f"{self.base_url}/api/think", json=payload, timeout=120)
            if resp.status_code == 200:
                data = resp.json()
                return data.get("data", str(data))
            return f"[API Error: {resp.status_code}]"
        except Exception as e:
            return f"[Connection Error: {e}]"


def load_cortex(model_name: str, db_path: str):
    """Try to attach to a running daemon; fall back to local cortex."""
    try:
        # Quick health‑check against the remote daemon
        resp = requests.get("http://localhost:8000/api/status", timeout=2)
        if resp.status_code == 200:
            print("✅ Remote daemon detected – using HolographicClient.")
            return HolographicClient()
    except Exception:
        pass
    print("⚠️  No remote daemon – loading local HolographicCortex (high RAM usage).")
    return HolographicCortex(model_name, db_path)


def fetch_prompts_from_db(db_path: str, max_rows: int):
    """Return a list of prompt strings from the DB.
    Tries common table names; if none exist, returns an empty list.
    """
    if not os.path.exists(db_path):
        print(f"⚠️  DB not found at {db_path}. Falling back to Faker.")
        return []
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    possible_tables = ["user_interactions", "interactions", "logs", "history"]
    prompts = []
    for tbl in possible_tables:
        try:
            cursor.execute(f"SELECT prompt FROM {tbl} LIMIT ?", (max_rows,))
            rows = cursor.fetchall()
            if rows:
                prompts = [r[0] for r in rows]
                print(f"✅ Retrieved {len(prompts)} prompts from table `{tbl}`.")
                break
        except sqlite3.OperationalError:
            # Table does not exist – try next
            continue
    conn.close()
    return prompts


def generate_faker_prompts(count: int):
    """Create `count` random but plausible OS‑style prompts using Faker."""
    from faker import Faker
    fake = Faker()
    prompts = []
    for _ in range(count):
        action = fake.word(ext_word_list=["diagnose", "visualize", "optimize", "query", "reset", "inspect"])
        target = fake.word(ext_word_list=["sensor", "memory", "network", "disk", "process", "module"])
        prompts.append(f"Please {action} the {target} status.")
    return prompts


def build_system_state() -> str:
    """Create a minimal system‑state string (mirrors GeometryOSShell.get_system_state)."""
    cwd = os.getcwd()
    timestamp = datetime.now().isoformat()
    files = os.listdir(cwd)[:5]
    return f"""
[SYSTEM CONTEXT]
TIME: {timestamp}
CWD: {cwd}
FILES: {', '.join(files)}
USER: Jericho
OS_GOAL: \"Autonomous Evolution\"
"""


def main():
    parser = argparse.ArgumentParser(description="Synthetic data daemon for Geometry OS")
    parser.add_argument("--model", required=True, help="Model node name (e.g. qwen2.5-coder-7b-instruct-q4_k_m)")
    parser.add_argument("--db", default="ctrm_llm_os.db", help="Path to Geometry OS SQLite DB")
    parser.add_argument("--output", required=True, help="JSONL file to append synthetic (prompt, response) pairs")
    parser.add_argument("--max-rows", type=int, default=500, help="Maximum number of prompts to generate")
    parser.add_argument("--sleep", type=float, default=0.0, help="Seconds to sleep between iterations (optional)")
    args = parser.parse_args()

    # Ensure output directory exists
    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)

    # Load Cortex (remote if daemon running, else local)
    cortex = load_cortex(args.model, args.db)

    # Try to pull real prompts from the DB; fall back to Faker if none.
    prompts = fetch_prompts_from_db(args.db, args.max_rows)
    if not prompts:
        print("⚡  No prompts found in DB – generating synthetic prompts via rich prompt registry.")
        # Use the rich prompt registry for diverse, OS-aware prompts
        from rich_prompt_registry import get_rich_prompts
        prompts = get_rich_prompts(args.max_rows)

    # Main generation loop
    for idx, user_prompt in enumerate(prompts, start=1):
        system_state = build_system_state()
        full_prompt = f"{system_state}\nHere is the user request: {user_prompt}"
        response = cortex.think(full_prompt)

        # Append to JSONL
        try:
            with open(args.output, "a", encoding="utf-8") as f:
                json.dump({"prompt": full_prompt, "response": response}, f)
                f.write("\n")
        except Exception as e:
            print(f"⚠️  Failed to write to {args.output}: {e}")
            continue

        print(f"🗂️  [{idx}/{len(prompts)}] Exported synthetic pair.")
        if args.sleep > 0:
            time.sleep(args.sleep)

    print(f"✅ Synthetic data generation complete. Output written to {args.output}")


if __name__ == "__main__":
    main()
