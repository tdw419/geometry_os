#!/usr/bin/env python3
"""
Holographic Diagnostic Tool
Self-test capability for the Geometry OS Neural Cortex.
"""
import time
import sys
import random

class HoloDiagnostic:
    def __init__(self):
        self.mock_mode = False

    def measure_latency(self, mock: bool = False) -> float:
        """
        Measure the neural latency of the cortex.
        If mock=True, returns a simulated latency (safe for builds).
        """
        if mock:
            # Simulate a neural spark (10-50ms)
            time.sleep(random.uniform(0.01, 0.05))
            return random.uniform(10.0, 50.0)
        
        # Real latency check (requires API)
        start = time.time()
        # In a real scenario, this would hit the internal API
        # For now, we simulate a heavier load
        time.sleep(0.1) 
        end = time.time()
        return (end - start) * 1000.0

    def run_diagnostics(self):
        print("🔍 Running Neural Diagnostic...")
        latency = self.measure_latency(mock=True)
        print(f"✅ Cortex Latency (Simulated): {latency:.2f}ms")
        return {"status": "GREEN", "latency": latency}

if __name__ == "__main__":
    # Self-test block for build verification
    print("🧪 Self-Test Initiated...")
    tool = HoloDiagnostic()
    result = tool.measure_latency(mock=True)
    if isinstance(result, float) and result > 0:
        print(f"✅ Self-Test Passed: {result:.2f}ms")
        sys.exit(0)
    else:
        print("❌ Self-Test Failed")
        sys.exit(1)
