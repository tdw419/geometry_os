#!/usr/bin/env python3
"""
    Geometry OS Native Bootloader
    -----------------------------
    This is the bootstrap kernel for Geometry OS. It replaces external shell scripts
    and allows the OS to manage its own lifecycle, environment, and "Holographic" state.
    
    Usage:
        python3 src/boot_sys.py
"""

import os
import sys
import json
import time
import signal
import asyncio
from pathlib import Path

# Constants
PROJECT_ROOT = Path(__file__).parent.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "settings.json"
RESTART_DELAY = 5  # Seconds between crash restarts

def load_config():
    """Load system configuration from JSON"""
    if not CONFIG_PATH.exists():
        print(f"⚠️ Config not found at {CONFIG_PATH}, using defaults.")
        return {}
    try:
        with open(CONFIG_PATH, "r") as f:
            return json.load(f)
    except Exception as e:
        print(f"❌ Config Load Error: {e}")
        return {}

def auto_activate_venv():
    """Auto-detect and activate virtual environment"""
    venv_path = PROJECT_ROOT / "geometry_os_env"
    if venv_path.exists():
        # Check if we are running from this venv
        if sys.prefix != str(venv_path):
            print(f"🔄 Switching to Neural Environment: {venv_path}")
            python_bin = venv_path / "bin" / "python3"
            if python_bin.exists():
                # Re-execute with the correct interpreter
                os.execv(str(python_bin), [str(python_bin)] + sys.argv)
            else:
                print("⚠️  Venv found but python3 binary missing.")

def configure_environment(config):
    """Set process environment variables based on config"""
    print("⚙️  Configuring Environment...")
    
    # Holographic Settings
    if config.get("holographic_mode", True):
        os.environ["USE_HOLOGRAPHIC"] = "true"
        os.environ["HOLO_MODEL"] = config.get("model", "phi-4")
        print(f"   🧠 Mode: HOLOGRAPHIC ({os.environ['HOLO_MODEL']})")
    
    # System Paths
    os.environ["GEOMETRY_ROOT"] = str(PROJECT_ROOT)
    os.environ["PYTHONPATH"] = str(PROJECT_ROOT) + ":" + os.environ.get("PYTHONPATH", "")
    
    # Ensure dependencies are available
    try:
        import llama_cpp
        print("   ✅ Neural Engine (llama-cpp-python) Detected")
    except ImportError:
        print("   ⚠️  Neural Engine Missing in current environment.")
        # Don't fallback yet, let the bootloader try to fix it via venv, 
        # but since we are already past venv check, this is a real error.
        print("   ⚠️  Falling back to API mode.")
        os.environ["USE_HOLOGRAPHIC"] = "false"

def signal_handler(sig, frame):
    """Handle shutdown signals gracefully"""
    print("\n🛑 System Suspend Signal Received. Shutting down...")
    sys.exit(0)

async def boot_kernel():
    """Boot the main OS Kernel"""
    # Import here to allow env vars to take effect
    sys.path.append(str(PROJECT_ROOT))
    
    try:
        from main import CTRMLLMOSDaemon
    except Exception as e:
        print(f"❌ Kernel Import Error: {e}")
        import traceback
        traceback.print_exc()
        return

    print("🌌 Initializing Geometry OS Kernel...")
    try:
        daemon = CTRMLLMOSDaemon()
        await daemon.initialize() # Initialize subsystems (DB, HAL, VFS)
    except Exception as e:
        print(f"❌ Daemon Init Error: {e}")
        import traceback
        traceback.print_exc()
        raise e
    
    # Run the continuous evolution loop
    try:
        await daemon.run_continual_evolution()
    except KeyboardInterrupt:
        print("🛑 User Interrupt")
    except Exception as e:
        print(f"❌ Kernel Panic: {e}")
        import traceback
        traceback.print_exc()
        raise e

def main():
    """Main Boot Loop"""
    # 0. Virtual Environment Check
    auto_activate_venv()

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    print("\n" + "="*40)
    print("   GEOMETRY OS - NATIVE BOOTLOADER   ")
    print("="*40 + "\n")

    while True:
        try:
            # 1. Load Configuration
            config = load_config()
            
            # 2. Configure Environment
            configure_environment(config)
            
            # 3. Boot Kernel
            asyncio.run(boot_kernel())
            
        except Exception as e:
            print(f"⚠️  System Crash: {e}")
            print(f"🔄 Rebooting in {RESTART_DELAY} seconds...")
            time.sleep(RESTART_DELAY)
        
        except KeyboardInterrupt:
            print("🛑 System Halted.")
            break

if __name__ == "__main__":
    main()
