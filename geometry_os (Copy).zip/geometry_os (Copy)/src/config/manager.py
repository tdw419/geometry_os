import os
import json
from typing import Any, Dict
from pathlib import Path

DEFAULT_CONFIG = {
    "system": {
        "adaptive_evolution": True,
        "debug_mode": False,
        "log_level": "INFO"
    },
    "self_healing": {
        "enabled": True,
        "max_attempts_per_hour": 5,
        "require_verification": True,
        "risky_file_patterns": ["kernel", "security", "auth"],
        "semantic_guardrails": True
    },
    "evolution": {
        "cycle_interval": 300,
        "min_efficiency": 0.3
    },
    "vector_engine": {
        "native_mode": True,
        "engine_type": "cvfs"
    }
}

class ConfigManager:
    """
    Central configuration management for Geometry OS.
    Loads from defaults -> file -> env vars.
    """
    def __init__(self, config_path: str = "config/settings.json"):
        self.config_path = config_path
        self._config = DEFAULT_CONFIG.copy()
        self.load_config()

    def load_config(self):
        """Load configuration from disk"""
        # Ensure config directory exists
        Path(self.config_path).parent.mkdir(parents=True, exist_ok=True)

        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    file_config = json.load(f)
                    self._merge_config(self._config, file_config)
                    print(f"⚙️ Loaded config from {self.config_path}")
            except Exception as e:
                print(f"⚠️ Failed to load config file: {e}")
        else:
            # Write defaults if missing
            self.save_config()

    def save_config(self):
        """Persist current config to disk"""
        try:
            with open(self.config_path, 'w') as f:
                json.dump(self._config, f, indent=4)
        except Exception as e:
            print(f"⚠️ Failed to save config: {e}")

    def get(self, key: str, default: Any = None) -> Any:
        """Get config value using dot notation (e.g. 'system.debug_mode')"""
        keys = key.split('.')
        value = self._config
        try:
            for k in keys:
                value = value[k]
            return value
        except KeyError:
            return default

    def set(self, key: str, value: Any):
        """Set config value using dot notation"""
        keys = key.split('.')
        target = self._config
        for k in keys[:-1]:
            target = target.setdefault(k, {})
        target[keys[-1]] = value
        self.save_config()

    def _merge_config(self, base: Dict, update: Dict):
        """Deep merge configuration dictionaries"""
        for k, v in update.items():
            if k in base and isinstance(base[k], dict) and isinstance(v, dict):
                self._merge_config(base[k], v)
            else:
                base[k] = v

# Global instance for easy access if needed
# config = ConfigManager()
