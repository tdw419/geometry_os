import asyncio
import json
import time
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
import sys
import os

# Add src to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from ctrm_core.founders_constitution import FoundersConstitution
from ctrm_core.code_prover import CodeProver

class AdaptiveEvolutionDaemon:
    def __init__(self, ctrm, token_manager, pattern_detector, version_control, conflict_resolver, motor_cortex=None):
        self.ctrm = ctrm
        self.tokens = token_manager
        self.pattern_detector = pattern_detector
        self.version_control = version_control
        self.conflict_resolver = conflict_resolver
        self.motor_cortex = motor_cortex
        self.base_frequency = 5  # Base cycle frequency in seconds
        self.current_adaptation = {
            "cycle_frequency": self.base_frequency,
            "evolution_aggressiveness": 0.5,
            "rollback_readiness": 0.3,
            "validation_intensity": 0.7
        }
        self.last_adaptation_time = 0
        self.adaptation_cooldown = 300  # 5 minutes cooldown
        self.constitution = FoundersConstitution()
        self.code_prover = CodeProver(motor_cortex=motor_cortex)

    async def adapt_evolution_cycle(self, pattern_shift_detected: bool = False) -> Dict[str, Any]:
        """Dynamically adapt evolution based on current conditions"""

        # Check cooldown period
        current_time = time.time()
        if current_time - self.last_adaptation_time < self.adaptation_cooldown and not pattern_shift_detected:
            return self.current_adaptation

        # Get current system state from CTRM
        system_state_truths = await self.ctrm.find_similar_truths(
            "system_state",
            limit=10
        )

        # Calculate adaptation parameters
        adaptation = {
            "cycle_frequency": self.base_frequency,
            "evolution_aggressiveness": 0.5,  # Default
            "rollback_readiness": 0.3,  # Default
            "validation_intensity": 0.7  # Default
        }

        # Adjust based on pattern shifts
        if pattern_shift_detected:
            # Slow down evolution, increase validation
            adaptation.update({
                "cycle_frequency": self.base_frequency * 2,  # Half frequency
                "evolution_aggressiveness": 0.2,  # More conservative
                "rollback_readiness": 0.8,  # Ready to rollback
                "validation_intensity": 0.9  # Intensive validation
            })

            # Create CTRM truth about adaptation
            adaptation_truth = await self.ctrm.create_truth(
                statement="Evolution adapted: pattern shift detected",
                context=json.dumps({
                    "confidence": 0.85,
                    "category": "evolution_adaptation",
                    "adaptation": adaptation,
                    "reason": "pattern_shift_detected",
                    "timestamp": datetime.now().isoformat()
                })
            )

            self.last_adaptation_time = current_time
            self.current_adaptation = adaptation

            return adaptation

        # Adjust based on recent failures
        recent_failures = await self.get_recent_failure_count(hours=1)
        if recent_failures > 2:
            adaptation.update({
                "evolution_aggressiveness": max(0.1, adaptation["evolution_aggressiveness"] - 0.2),
                "validation_intensity": min(1.0, adaptation["validation_intensity"] + 0.2)
            })

        # Adjust based on token efficiency
        efficiency_status = await self.tokens.get_efficiency_status()
        if efficiency_status.get("conservation_mode", False):
            adaptation.update({
                "cycle_frequency": self.base_frequency * 1.5,
                "evolution_aggressiveness": 0.3,
                "validation_intensity": 0.8
            })
        elif efficiency_status.get("average_efficiency", 0) > 0.002:
            adaptation.update({
                "cycle_frequency": max(3, self.base_frequency * 0.8),
                "evolution_aggressiveness": min(0.7, adaptation["evolution_aggressiveness"] + 0.1)
            })

        # Adjust based on confidence trends
        confidence_trend = await self.get_confidence_trend()
        if confidence_trend < -0.1:  # Confidence decreasing
            adaptation.update({
                "evolution_aggressiveness": max(0.2, adaptation["evolution_aggressiveness"] - 0.1),
                "validation_intensity": min(0.9, adaptation["validation_intensity"] + 0.1)
            })
        elif confidence_trend > 0.1:  # Confidence increasing
            adaptation.update({
                "evolution_aggressiveness": min(0.8, adaptation["evolution_aggressiveness"] + 0.1)
            })

        # Create CTRM truth about adaptation
        adaptation_truth = await self.ctrm.create_truth(
            statement="Evolution adapted: dynamic parameters",
            context=json.dumps({
                "confidence": 0.8,
                "category": "evolution_adaptation",
                "adaptation": adaptation,
                "reason": "dynamic_adaptation",
                "timestamp": datetime.now().isoformat()
            })
        )

        self.last_adaptation_time = current_time
        self.current_adaptation = adaptation

        return adaptation

    async def get_recent_failure_count(self, hours: int = 1) -> int:
        """Get count of recent evolution failures"""
        cutoff_time = datetime.now() - timedelta(hours=hours)

        # Query CTRM for recent failures
        failure_truths = await self.ctrm.find_similar_truths(
            "evolution failure",
            limit=10
        )

        recent_failures = 0
        for truth in failure_truths:
            try:
                metadata = truth.get("metadata", {})
                context = metadata.get("context", "{}")
                if context:
                    context_data = json.loads(context)
                    failure_time_str = context_data.get("timestamp")
                    if failure_time_str:
                        failure_time = datetime.fromisoformat(failure_time_str)
                        if failure_time >= cutoff_time:
                            recent_failures += 1
            except (json.JSONDecodeError, ValueError, KeyError):
                continue

        return recent_failures

    async def get_confidence_trend(self) -> float:
        """Get confidence trend from recent evolution cycles"""
        # Query CTRM for recent confidence truths
        confidence_truths = await self.ctrm.find_similar_truths(
            "confidence score",
            limit=10
        )

        if len(confidence_truths) < 3:
            return 0.0

        # Calculate trend
        confidences = [t.get("confidence", 0.7) for t in confidence_truths]
        trend = (confidences[-1] - confidences[0]) / len(confidences)

        return trend

    async def get_current_adaptation(self) -> Dict[str, Any]:
        """Get current adaptation parameters"""
        return self.current_adaptation

    async def apply_adaptation_to_cycle(self, evolution_cycle_params: Dict[str, Any]) -> Dict[str, Any]:
        """Apply current adaptation to evolution cycle parameters"""

        adaptation = self.current_adaptation

        # Adjust cycle parameters based on adaptation
        adapted_params = evolution_cycle_params.copy()

        # Apply aggressiveness to token budgets
        if "analysis_budget" in adapted_params:
            adapted_params["analysis_budget"] = int(adapted_params["analysis_budget"] * adaptation["evolution_aggressiveness"])
        if "evolution_budget" in adapted_params:
            adapted_params["evolution_budget"] = int(adapted_params["evolution_budget"] * adaptation["evolution_aggressiveness"])
        if "validation_budget" in adapted_params:
            adapted_params["validation_budget"] = int(adapted_params["validation_budget"] * adaptation["validation_intensity"])

        # Apply validation intensity to validation thresholds
        if "validation_threshold" in adapted_params:
            adapted_params["validation_threshold"] = max(0.6, adapted_params["validation_threshold"] - (1 - adaptation["validation_intensity"]) * 0.2)

        return adapted_params

    async def check_adaptation_stability(self) -> Dict[str, Any]:
        """Check if current adaptation is stable"""

        # Check for oscillation patterns
        adaptation_truths = await self.ctrm.find_similar_truths(
            "evolution adaptation",
            limit=5
        )

        if len(adaptation_truths) < 3:
            return {
                "stable": True,
                "reason": "insufficient_history",
                "confidence": 0.9
            }

        # Check for oscillation in aggressiveness
        aggressiveness_values = []
        for truth in adaptation_truths:
            try:
                metadata = truth.get("metadata", {})
                context = metadata.get("context", "{}")
                if context:
                    context_data = json.loads(context)
                    adaptation = context_data.get("adaptation", {})
                    aggressiveness_values.append(adaptation.get("evolution_aggressiveness", 0.5))
            except (json.JSONDecodeError, ValueError, KeyError):
                continue

        if len(aggressiveness_values) >= 3:
            # Check for oscillation pattern
            oscillation_score = 0
            for i in range(1, len(aggressiveness_values)):
                delta = aggressiveness_values[i] - aggressiveness_values[i-1]
                oscillation_score += abs(delta)

            avg_oscillation = oscillation_score / (len(aggressiveness_values) - 1)

            if avg_oscillation > 0.2:  # Significant oscillation
                return {
                    "stable": False,
                    "reason": "aggressiveness_oscillation",
                    "confidence": 0.8,
                    "oscillation_score": avg_oscillation
                }

        return {
            "stable": True,
            "reason": "no_oscillation_detected",
            "confidence": 0.9
        }

    async def stabilize_adaptation(self) -> Dict[str, Any]:
        """Stabilize adaptation when oscillation is detected"""

        # Reset to more conservative settings
        stabilized_adaptation = {
            "cycle_frequency": self.base_frequency * 1.2,
            "evolution_aggressiveness": 0.4,
            "rollback_readiness": 0.5,
            "validation_intensity": 0.8
        }

        # Create CTRM truth about stabilization
        stabilization_truth = await self.ctrm.create_truth(
            statement="Evolution adaptation stabilized",
            context=json.dumps({
                "confidence": 0.85,
                "category": "evolution_stabilization",
                "previous_adaptation": self.current_adaptation,
                "new_adaptation": stabilized_adaptation,
                "reason": "oscillation_detected",
                "timestamp": datetime.now().isoformat()
            })
        )

        self.current_adaptation = stabilized_adaptation
        self.last_adaptation_time = time.time()

        return {
            "stabilized": True,
            "new_adaptation": stabilized_adaptation,
            "ctrm_truth_id": stabilization_truth.id
        }

    async def verify_evolution_safety(self, evolution_plan: str) -> Dict[str, Any]:
        """
        Verify that an evolution plan complies with the Founders Constitution
        before attempting to execute it.
        """
        # Check against constitution axioms
        constitution_compliant = self.constitution.check_compliance(evolution_plan)

        # Create CTRM truth about the safety check
        safety_truth = await self.ctrm.create_truth(
            statement=f"Evolution safety check: {'compliant' if constitution_compliant else 'violation'}",
            context=json.dumps({
                "confidence": 0.95 if constitution_compliant else 0.05,
                "category": "evolution_safety",
                "evolution_plan": evolution_plan,
                "constitution_compliant": constitution_compliant,
                "timestamp": datetime.now().isoformat()
            })
        )

        return {
            "safe": constitution_compliant,
            "ctrm_truth_id": safety_truth.id,
            "message": "Evolution plan is constitutionally compliant" if constitution_compliant else "Evolution plan violates constitution"
        }

    async def safe_evolve_code(self, code: str, language: str = "python") -> Dict[str, Any]:
        """
        Safely evolve code using the CodeProver to ensure it's functional and safe
        before applying any changes.
        """
        # First verify the code against constitution
        constitution_check = await self.verify_evolution_safety(code)
        if not constitution_check["safe"]:
            return {
                "success": False,
                "error": "Code violates Founders Constitution",
                "constitution_check": constitution_check
            }

        # Use CodeProver to verify the code works
        prover_result = await self.code_prover.prove_code(code, language)

        # Create CTRM truth about the evolution attempt
        evolution_truth = await self.ctrm.create_truth(
            statement=f"Code evolution attempt: {'success' if prover_result['verified'] else 'failure'}",
            context=json.dumps({
                "confidence": 0.9 if prover_result['verified'] else 0.1,
                "category": "code_evolution",
                "code_length": len(code),
                "language": language,
                "verified": prover_result['verified'],
                "constitution_compliant": prover_result.get('constitution_compliant', True),
                "timestamp": datetime.now().isoformat()
            })
        )

        return {
            "success": prover_result['verified'],
            "verified_code": prover_result['code'] if prover_result['verified'] else None,
            "execution_result": prover_result['execution_result'],
            "constitution_check": constitution_check,
            "ctrm_truth_id": evolution_truth.id
        }

    async def apply_safe_evolution(self, evolution_plan: Dict[str, Any]) -> Dict[str, Any]:
        """
        Apply a complete evolution cycle with full safety checks and verification.
        """
        # Step 1: Verify the evolution plan is safe
        plan_safety = await self.verify_evolution_safety(json.dumps(evolution_plan))
        if not plan_safety["safe"]:
            return {
                "success": False,
                "error": "Evolution plan violates constitution",
                "safety_check": plan_safety
            }

        # Step 2: Apply adaptation to cycle parameters
        adapted_params = await self.apply_adaptation_to_cycle(evolution_plan.get("cycle_params", {}))

        # Step 3: If there are code changes, verify them
        code_changes = evolution_plan.get("code_changes", {})
        evolution_results = {}

        for file_path, code_change in code_changes.items():
            language = code_change.get("language", "python")
            new_code = code_change.get("code", "")

            result = await self.safe_evolve_code(new_code, language)
            evolution_results[file_path] = result

            # If any code change fails, abort the evolution
            if not result["success"]:
                return {
                    "success": False,
                    "error": f"Code verification failed for {file_path}",
                    "failed_file": file_path,
                    "evolution_results": evolution_results,
                    "safety_check": plan_safety
                }

        # Step 4: All checks passed, create final evolution truth
        final_truth = await self.ctrm.create_truth(
            statement="Evolution cycle completed successfully",
            context=json.dumps({
                "confidence": 0.95,
                "category": "evolution_completion",
                "evolution_plan": evolution_plan,
                "adapted_params": adapted_params,
                "evolution_results": evolution_results,
                "timestamp": datetime.now().isoformat()
            })
        )

        return {
            "success": True,
            "adapted_params": adapted_params,
            "evolution_results": evolution_results,
            "safety_check": plan_safety,
            "ctrm_truth_id": final_truth.id
        }