/**
 * Geometry OS Holographic Dashboard
 * Real-time hardware telemetry visualization
 */

class HolographicDashboard {
    constructor() {
        this.apiBaseUrl = '/api';
        this.refreshInterval = 5000; // 5 seconds
        this.telemetryInterval = 2000; // 2 seconds
        this.deviceTypeChart = null;
        this.networkChart = null;
        this.telemetryData = {};
        this.deviceHealthData = {};
        this.systemLogs = [];

        // Initialize dashboard
        this.init();
    }

    init() {
        console.log('🚀 Initializing Holographic Dashboard');

        // Set up event listeners
        this.setupEventListeners();

        // Initialize charts
        this.initCharts();

        // Start data fetching
        this.startDataFetching();

        // Update system time
        this.updateSystemTime();
        setInterval(() => this.updateSystemTime(), 1000);

        this.addLog('Holographic Dashboard initialized successfully');
    }

    setupEventListeners() {
        // Refresh button
        document.getElementById('refresh-btn').addEventListener('click', () => {
            this.fetchAllData();
            this.addLog('Manual data refresh triggered');
        });

        // Fullscreen button
        document.getElementById('fullscreen-btn').addEventListener('click', () => {
            this.toggleFullscreen();
        });

        // Settings button
        document.getElementById('settings-btn').addEventListener('click', () => {
            this.addLog('Settings button clicked (feature coming soon)');
        });
    }

    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => {
                console.error('Error attempting to enable fullscreen:', err);
                this.addLog('Fullscreen mode failed');
            });
        } else {
            document.exitFullscreen();
        }
    }

    initCharts() {
        // Device type chart
        const deviceTypeCtx = document.getElementById('device-type-chart').getContext('2d');
        this.deviceTypeChart = new Chart(deviceTypeCtx, {
            type: 'doughnut',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        'rgba(0, 240, 255, 0.7)',
                        'rgba(255, 0, 160, 0.7)',
                        'rgba(160, 0, 255, 0.7)',
                        'rgba(0, 255, 136, 0.7)',
                        'rgba(255, 204, 0, 0.7)',
                        'rgba(255, 68, 68, 0.7)'
                    ],
                    borderColor: [
                        'rgba(0, 240, 255, 1)',
                        'rgba(255, 0, 160, 1)',
                        'rgba(160, 0, 255, 1)',
                        'rgba(0, 255, 136, 1)',
                        'rgba(255, 204, 0, 1)',
                        'rgba(255, 68, 68, 1)'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#ffffff',
                            font: {
                                size: 12
                            }
                        }
                    },
                    title: {
                        display: true,
                        text: 'Device Type Distribution',
                        color: '#00f0ff',
                        font: {
                            size: 14,
                            weight: 'bold'
                        }
                    }
                }
            }
        });

        // Network chart
        const networkCtx = document.getElementById('network-chart').getContext('2d');
        this.networkChart = new Chart(networkCtx, {
            type: 'line',
            data: {
                labels: Array(10).fill('').map((_, i) => ''),
                datasets: [
                    {
                        label: 'Bandwidth In',
                        data: Array(10).fill(0),
                        borderColor: 'rgba(0, 240, 255, 1)',
                        backgroundColor: 'rgba(0, 240, 255, 0.2)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Bandwidth Out',
                        data: Array(10).fill(0),
                        borderColor: 'rgba(255, 0, 160, 1)',
                        backgroundColor: 'rgba(255, 0, 160, 0.2)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: '#ffffff'
                        },
                        grid: {
                            color: 'rgba(0, 240, 255, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#ffffff'
                        },
                        grid: {
                            color: 'rgba(0, 240, 255, 0.1)'
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: '#ffffff'
                        }
                    }
                }
            }
        });
    }

    startDataFetching() {
        // Initial data fetch
        this.fetchAllData();

        // Set up periodic refresh
        setInterval(() => this.fetchStatusData(), this.refreshInterval);
        setInterval(() => this.fetchTelemetryData(), this.telemetryInterval);
    }

    async fetchAllData() {
        try {
            await Promise.all([
                this.fetchStatusData(),
                this.fetchSystemData(),
                this.fetchDeviceData(),
                this.fetchTelemetryData(),
                this.fetchHealthData()
            ]);
            this.addLog('🔄 All data refreshed successfully');
        } catch (error) {
            console.error('Error fetching all data:', error);
            this.addLog(`❌ Error refreshing data: ${error.message}`);
        }
    }

    async fetchStatusData() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/status`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

            const data = await response.json();

            // Update UI
            document.getElementById('hal-state').textContent = `HAL: ${data.data.hal_state.state}`;
            document.getElementById('hal-state').className = `status-item status-${data.data.hal_state.state.toLowerCase()}`;

            document.getElementById('device-count').textContent = `Devices: ${data.data.hal_state.operational_devices}`;

            // Update health status
            const healthStatus = data.data.health.overall_health.toUpperCase();
            const healthElement = document.getElementById('system-health');
            healthElement.textContent = healthStatus;
            healthElement.className = `health-status health-${healthStatus.toLowerCase()}`;

            // Update health counts
            document.getElementById('health-good').textContent = data.data.health.issues.filter(i => i.includes('good')).length || '0';
            document.getElementById('health-warning').textContent = data.data.health.issues.filter(i => i.includes('warning')).length || '0';
            document.getElementById('health-critical').textContent = data.data.health.issues.filter(i => i.includes('critical')).length || '0';

        } catch (error) {
            console.error('Error fetching status:', error);
            this.addLog(`❌ Status fetch failed: ${error.message}`);
        }
    }

    async fetchSystemData() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/system`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

            const data = await response.json();

            // Update UI
            document.getElementById('system-os').textContent = data.data.system.os || 'Unknown';
            document.getElementById('system-arch').textContent = data.data.system.architecture || 'Unknown';
            document.getElementById('total-devices').textContent = data.data.device_count || '0';
            document.getElementById('operational-devices').textContent = data.data.operational_devices || '0';

            // Update device type chart
            if (data.data.device_types) {
                const deviceTypes = data.data.device_types;
                const labels = Object.keys(deviceTypes);
                const values = Object.values(deviceTypes);

                this.deviceTypeChart.data.labels = labels;
                this.deviceTypeChart.data.datasets[0].data = values;
                this.deviceTypeChart.update();

                // Update device count
                document.getElementById('device-count').textContent = `Devices: ${values.reduce((a, b) => a + b, 0)}`;
            }

        } catch (error) {
            console.error('Error fetching system data:', error);
            this.addLog(`❌ System data fetch failed: ${error.message}`);
        }
    }

    async fetchDeviceData() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/devices`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

            const data = await response.json();

            // Update device health list
            const healthList = document.getElementById('device-health-list');
            healthList.innerHTML = '';

            data.data.devices.forEach(device => {
                const deviceItem = document.createElement('div');
                deviceItem.className = `device-health-item ${device.state.toLowerCase()}`;

                const healthStatus = device.is_operational ? 'good' : 'error';
                const statusText = device.is_operational ? 'Operational' : 'Error';

                deviceItem.innerHTML = `
                    <span class="device-name">${device.name} (${device.type})</span>
                    <span class="device-status">${statusText}</span>
                `;

                healthList.appendChild(deviceItem);
            });

        } catch (error) {
            console.error('Error fetching device data:', error);
            this.addLog(`❌ Device data fetch failed: ${error.message}`);
        }
    }

    async fetchTelemetryData() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/telemetry`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

            const data = await response.json();

            // Update telemetry grid
            const telemetryGrid = document.getElementById('telemetry-grid');
            telemetryGrid.innerHTML = '';

            // Group devices by type for telemetry display
            const devicesByType = {};
            data.data.devices.forEach(device => {
                if (!devicesByType[device.type]) {
                    devicesByType[device.type] = [];
                }
                devicesByType[device.type].push(device);
            });

            // Display telemetry for each device type
            for (const [type, devices] of Object.entries(devicesByType)) {
                const typeHeader = document.createElement('div');
                typeHeader.className = 'telemetry-item type-header';
                typeHeader.innerHTML = `<span class="telemetry-label">${type.toUpperCase()} DEVICES</span>`;
                telemetryGrid.appendChild(typeHeader);

                devices.forEach(device => {
                    const telemetryItem = document.createElement('div');
                    telemetryItem.className = 'telemetry-item';

                    let telemetryContent = `
                        <span class="telemetry-label">${device.name}</span>
                        <span class="telemetry-value">${device.state}</span>
                    `;

                    // Add specialized telemetry
                    if (device.cpu_usage) {
                        telemetryContent += `<span class="telemetry-value">CPU: ${device.cpu_usage}%</span>`;
                    } else if (device.memory_stats) {
                        telemetryContent += `<span class="telemetry-value">MEM: ${device.memory_stats.used}%</span>`;
                    } else if (device.disk_stats) {
                        telemetryContent += `<span class="telemetry-value">DISK: ${device.disk_stats.used}%</span>`;
                    } else if (device.network_stats) {
                        telemetryContent += `
                            <span class="telemetry-value">IN: ${this.formatBytes(device.network_stats.bytes_recv)}</span>
                            <span class="telemetry-value">OUT: ${this.formatBytes(device.network_stats.bytes_sent)}</span>
                        `;
                    }

                    telemetryItem.innerHTML = telemetryContent;
                    telemetryGrid.appendChild(telemetryItem);
                });
            }

            // Update network stats
            const networkDevices = data.data.devices.filter(d => d.type === 'network');
            if (networkDevices.length > 0) {
                const networkDevice = networkDevices[0];
                if (networkDevice.network_stats) {
                    const stats = networkDevice.network_stats;
                    document.getElementById('bandwidth-in').textContent = this.formatBytes(stats.bytes_recv);
                    document.getElementById('bandwidth-out').textContent = this.formatBytes(stats.bytes_sent);
                    document.getElementById('total-traffic').textContent = this.formatBytes(stats.bytes_recv + stats.bytes_sent);
                    document.getElementById('network-errors').textContent = stats.errors_in + stats.errors_out;

                    // Update network chart
                    this.updateNetworkChart(stats.bytes_recv, stats.bytes_sent);
                }
            }

        } catch (error) {
            console.error('Error fetching telemetry:', error);
            this.addLog(`❌ Telemetry fetch failed: ${error.message}`);
        }
    }

    async fetchHealthData() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/health`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

            const data = await response.json();

            // Update health counts
            const goodCount = Object.values(data.data.device_statuses).filter(d => d.health === 'good').length;
            const warningCount = Object.values(data.data.device_statuses).filter(d => d.health === 'warning').length;
            const criticalCount = Object.values(data.data.device_statuses).filter(d => d.health === 'critical').length;

            document.getElementById('health-good').textContent = goodCount;
            document.getElementById('health-warning').textContent = warningCount;
            document.getElementById('health-critical').textContent = criticalCount;

        } catch (error) {
            console.error('Error fetching health data:', error);
            this.addLog(`❌ Health data fetch failed: ${error.message}`);
        }
    }

    updateNetworkChart(bytesIn, bytesOut) {
        // Shift data and add new values
        this.networkChart.data.labels.shift();
        this.networkChart.data.labels.push('');

        this.networkChart.data.datasets[0].data.shift();
        this.networkChart.data.datasets[0].data.push(bytesIn / (1024 * 1024)); // Convert to MB

        this.networkChart.data.datasets[1].data.shift();
        this.networkChart.data.datasets[1].data.push(bytesOut / (1024 * 1024)); // Convert to MB

        this.networkChart.update();
    }

    updateSystemTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });

        const dateString = now.toLocaleDateString('en-US', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });

        document.getElementById('system-time').textContent = timeString;
        document.getElementById('system-date').textContent = dateString;
    }

    addLog(message) {
        const logsContainer = document.getElementById('system-logs');
        const logEntry = document.createElement('div');
        logEntry.className = 'log-entry';

        const timestamp = new Date().toLocaleString('en-US', {
            year: '2-digit',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });

        logEntry.textContent = `[${timestamp}] ${message}`;
        logsContainer.appendChild(logEntry);

        // Keep only the last 20 log entries
        if (logsContainer.children.length > 20) {
            logsContainer.removeChild(logsContainer.firstChild);
        }

        // Scroll to bottom
        logsContainer.scrollTop = logsContainer.scrollHeight;
    }

    formatBytes(bytes) {
        if (bytes === 0) return '0 B';

        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    formatPercentage(value) {
        return value.toFixed(1) + '%';
    }
}

// Initialize the dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('🌐 Holographic Dashboard DOM loaded');
    new HolographicDashboard();
});