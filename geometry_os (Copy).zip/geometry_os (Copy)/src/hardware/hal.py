#!/usr/bin/env python3
"""
Hardware Abstraction Layer (HAL) for Geometry OS
Main interface between the OS daemon and hardware components
"""

import json
import logging
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass
import threading
import time
from enum import Enum, auto

# Local imports
from hardware.discovery import HardwareDiscovery, discover_hardware
from hardware.drivers.neural_driver_base import (
    NeuralDriverBase, create_neural_driver, DriverState
)

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class HALState(Enum):
    """HAL state enumeration"""
    UNINITIALIZED = auto()
    INITIALIZING = auto()
    READY = auto()
    OPERATIONAL = auto()
    DEGRADED = auto()
    ERROR = auto()
    SHUTDOWN = auto()

class HALEventType(Enum):
    """HAL event types"""
    DEVICE_DISCOVERED = auto()
    DEVICE_INITIALIZED = auto()
    DEVICE_REMOVED = auto()
    DRIVER_ERROR = auto()
    STATE_CHANGE = auto()

@dataclass
class HALEvent:
    """HAL event data class"""
    event_type: HALEventType
    timestamp: float
    component_id: str = None
    message: str = None
    data: Dict[str, Any] = None

class HardwareAbstractionLayer:
    """Main Hardware Abstraction Layer class"""

    def __init__(self):
        """Initialize the HAL"""
        self.state = HALState.UNINITIALIZED
        self.discovery = HardwareDiscovery()
        self.drivers = {}  # device_id -> NeuralDriverBase
        self.hardware_profile = None
        self.event_listeners = []
        self.lock = threading.Lock()
        self.error_count = 0
        self.operational_devices = 0

        # Initialize logging
        self.logger = logging.getLogger('HAL')

    def initialize(self) -> bool:
        """Initialize the HAL"""
        try:
            self.state = HALState.INITIALIZING
            self.logger.info("Initializing Hardware Abstraction Layer")

            # Discover hardware
            self.hardware_profile = self.discovery.scan_system()
            self.logger.info(f"Discovered {len(self.hardware_profile['components'])} hardware components")

            # Initialize drivers for all components
            self._initialize_drivers()

            self.state = HALState.READY
            self.logger.info("HAL initialized successfully")
            self._trigger_event(HALEventType.STATE_CHANGE, message="HAL ready")

            return True

        except Exception as e:
            self.state = HALState.ERROR
            self.logger.error(f"Failed to initialize HAL: {str(e)}")
            self._trigger_event(HALEventType.STATE_CHANGE, message=f"HAL error: {str(e)}")
            return False

    def _initialize_drivers(self):
        """Initialize drivers for all discovered components"""
        for component in self.hardware_profile['components']:
            try:
                device_id = component.get('device_id', component.get('bus_info', str(len(self.drivers))))
                driver = create_neural_driver(component)

                if driver.initialize():
                    self.drivers[device_id] = driver
                    self.operational_devices += 1
                    self.logger.info(f"Initialized driver for {component.get('name', 'unknown device')}")
                    self._trigger_event(
                        HALEventType.DEVICE_INITIALIZED,
                        component_id=device_id,
                        message=f"Driver initialized for {component.get('name', 'unknown device')}"
                    )
                else:
                    self.error_count += 1
                    self.logger.warning(f"Failed to initialize driver for {component.get('name', 'unknown device')}")

            except Exception as e:
                self.error_count += 1
                self.logger.error(f"Error initializing driver for {component.get('name', 'unknown device')}: {str(e)}")
                self._trigger_event(
                    HALEventType.DRIVER_ERROR,
                    component_id=component.get('device_id', 'unknown'),
                    message=str(e)
                )

    def shutdown(self) -> bool:
        """Shutdown the HAL"""
        try:
            self.state = HALState.SHUTDOWN
            self.logger.info("Shutting down Hardware Abstraction Layer")

            # Shutdown all drivers
            for device_id, driver in self.drivers.items():
                try:
                    driver.shutdown()
                    self.logger.info(f"Shut down driver for {device_id}")
                except Exception as e:
                    self.logger.error(f"Error shutting down driver {device_id}: {str(e)}")

            self.drivers.clear()
            self.logger.info("HAL shutdown complete")
            return True

        except Exception as e:
            self.logger.error(f"Failed to shutdown HAL: {str(e)}")
            return False

    def get_state(self) -> HALState:
        """Get current HAL state"""
        return self.state

    def get_hardware_profile(self) -> Dict[str, Any]:
        """Get the current hardware profile"""
        return self.hardware_profile

    def get_driver(self, device_id: str) -> Optional[NeuralDriverBase]:
        """Get driver by device ID"""
        return self.drivers.get(device_id)

    def get_all_drivers(self) -> Dict[str, NeuralDriverBase]:
        """Get all drivers"""
        return self.drivers

    def get_operational_status(self) -> Dict[str, Any]:
        """Get operational status of the HAL"""
        return {
            'state': self.state.name,
            'total_devices': len(self.drivers),
            'operational_devices': self.operational_devices,
            'error_count': self.error_count,
            'uptime': self._get_uptime()
        }

    def _get_uptime(self) -> float:
        """Get HAL uptime in seconds"""
        # In a real implementation, this would track actual uptime
        return time.time() - self._get_start_time()

    def _get_start_time(self) -> float:
        """Get HAL start time"""
        # Simple implementation - in reality would track actual start time
        return time.time() - 60  # Assume 60 seconds uptime for demo

    def refresh_hardware(self) -> Dict[str, Any]:
        """Refresh hardware discovery and update drivers"""
        try:
            self.logger.info("Refreshing hardware discovery")

            # Get current device IDs
            current_device_ids = set(self.drivers.keys())

            # Discover new hardware
            new_hardware_profile = self.discovery.scan_system()
            new_device_ids = set()

            # Initialize drivers for new components
            for component in new_hardware_profile['components']:
                device_id = component.get('device_id', component.get('bus_info', str(len(self.drivers))))

                if device_id not in self.drivers:
                    # New device discovered
                    driver = create_neural_driver(component)
                    if driver.initialize():
                        self.drivers[device_id] = driver
                        self.operational_devices += 1
                        self.logger.info(f"Discovered and initialized new device: {component.get('name', 'unknown')}")
                        self._trigger_event(
                            HALEventType.DEVICE_DISCOVERED,
                            component_id=device_id,
                            message=f"New device discovered: {component.get('name', 'unknown')}"
                        )
                    else:
                        self.error_count += 1
                        self.logger.warning(f"Failed to initialize driver for new device: {component.get('name', 'unknown')}")

                new_device_ids.add(device_id)

            # Check for removed devices
            removed_devices = current_device_ids - new_device_ids
            for device_id in removed_devices:
                if device_id in self.drivers:
                    driver = self.drivers[device_id]
                    driver.shutdown()
                    del self.drivers[device_id]
                    self.logger.info(f"Device removed: {device_id}")
                    self._trigger_event(
                        HALEventType.DEVICE_REMOVED,
                        component_id=device_id,
                        message=f"Device removed: {device_id}"
                    )

            # Update hardware profile
            self.hardware_profile = new_hardware_profile

            return self.get_operational_status()

        except Exception as e:
            self.logger.error(f"Error refreshing hardware: {str(e)}")
            self.error_count += 1
            return {'error': str(e)}

    def get_device_status(self, device_id: str) -> Dict[str, Any]:
        """Get status of a specific device"""
        driver = self.get_driver(device_id)
        if not driver:
            return {'error': 'Device not found'}

        return {
            'device_id': device_id,
            'state': driver.get_state().name,
            'is_operational': driver.is_operational(),
            'capabilities': [cap.name for cap in driver.get_capabilities()],
            'component_info': driver.get_component_info()
        }

    def get_system_summary(self) -> Dict[str, Any]:
        """Get system hardware summary"""
        if not self.hardware_profile:
            return {'error': 'HAL not initialized'}

        summary = {
            'system': self.hardware_profile['system_info'],
            'device_count': len(self.hardware_profile['components']),
            'operational_devices': self.operational_devices,
            'hal_state': self.state.name,
            'timestamp': self.hardware_profile['timestamp']
        }

        # Count device types
        device_types = {}
        for component in self.hardware_profile['components']:
            comp_type = component['component_type']
            device_types[comp_type] = device_types.get(comp_type, 0) + 1

        summary['device_types'] = device_types

        return summary

    def add_event_listener(self, listener: callable):
        """Add event listener"""
        self.event_listeners.append(listener)

    def remove_event_listener(self, listener: callable):
        """Remove event listener"""
        if listener in self.event_listeners:
            self.event_listeners.remove(listener)

    def _trigger_event(self, event_type: HALEventType, component_id: str = None, message: str = None, data: Dict[str, Any] = None):
        """Trigger HAL event"""
        event = HALEvent(
            event_type=event_type,
            timestamp=time.time(),
            component_id=component_id,
            message=message,
            data=data
        )

        # Notify all listeners
        for listener in self.event_listeners:
            try:
                listener(event)
            except Exception as e:
                self.logger.error(f"Error in event listener: {str(e)}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert HAL state to dictionary"""
        return {
            'state': self.state.name,
            'device_count': len(self.drivers),
            'operational_devices': self.operational_devices,
            'error_count': self.error_count,
            'system_info': self.hardware_profile['system_info'] if self.hardware_profile else None,
            'drivers': {device_id: driver.to_dict() for device_id, driver in self.drivers.items()}
        }

    def to_json(self) -> str:
        """Convert HAL state to JSON"""
        return json.dumps(self.to_dict(), indent=2)

    def save_state(self, file_path: str) -> bool:
        """Save HAL state to file"""
        try:
            with open(file_path, 'w') as f:
                f.write(self.to_json())
            return True
        except Exception as e:
            self.logger.error(f"Error saving HAL state: {str(e)}")
            return False

    def load_state(self, file_path: str) -> bool:
        """Load HAL state from file (for debugging/persistence)"""
        try:
            with open(file_path, 'r') as f:
                state_data = json.load(f)

            # This is a simplified load - in reality would be more complex
            self.logger.info(f"Loaded HAL state from {file_path}")
            return True
        except Exception as e:
            self.logger.error(f"Error loading HAL state: {str(e)}")
            return False

class HALMonitor:
    """HAL monitoring and health checking"""

    def __init__(self, hal: HardwareAbstractionLayer):
        self.hal = hal
        self.logger = logging.getLogger('HALMonitor')

    def check_health(self) -> Dict[str, Any]:
        """Check overall HAL health"""
        status = self.hal.get_operational_status()

        health_status = {
            'overall_health': 'good',
            'issues': []
        }

        if status['state'] == HALState.ERROR.name:
            health_status['overall_health'] = 'critical'
            health_status['issues'].append('HAL in error state')
        elif status['state'] == HALState.DEGRADED.name:
            health_status['overall_health'] = 'degraded'
            health_status['issues'].append('HAL in degraded state')
        elif status['error_count'] > 0:
            health_status['overall_health'] = 'warning'
            health_status['issues'].append(f'{status["error_count"]} driver errors')

        if status['operational_devices'] == 0:
            health_status['overall_health'] = 'critical'
            health_status['issues'].append('No operational devices')

        return health_status

    def get_detailed_health_report(self) -> Dict[str, Any]:
        """Get detailed health report"""
        report = {
            'hal_status': self.hal.get_operational_status(),
            'device_statuses': {},
            'health_summary': self.check_health()
        }

        # Get status for each device
        for device_id, driver in self.hal.get_all_drivers().items():
            report['device_statuses'][device_id] = {
                'state': driver.get_state().name,
                'is_operational': driver.is_operational(),
                'error': str(driver.error) if driver.error else None
            }

        return report

def create_hal() -> HardwareAbstractionLayer:
    """Create and initialize a HAL instance"""
    hal = HardwareAbstractionLayer()
    if hal.initialize():
        return hal
    else:
        raise RuntimeError("Failed to initialize HAL")

def main():
    """Test the HAL"""
    print("Creating Hardware Abstraction Layer...")
    hal = create_hal()

    print(f"HAL State: {hal.get_state()}")
    print(f"Operational Status: {hal.get_operational_status()}")

    # Get system summary
    summary = hal.get_system_summary()
    print(f"\nSystem Summary:")
    print(f"  OS: {summary['system']['os']}")
    print(f"  Architecture: {summary['system']['architecture']}")
    print(f"  Total Devices: {summary['device_count']}")
    print(f"  Device Types: {summary['device_types']}")

    # Test event listening
    def event_listener(event: HALEvent):
        print(f"HAL Event: {event.event_type.name} - {event.message}")

    hal.add_event_listener(event_listener)

    # Test refresh
    print("\nRefreshing hardware...")
    refresh_result = hal.refresh_hardware()
    print(f"Refresh result: {refresh_result}")

    # Test health monitoring
    monitor = HALMonitor(hal)
    health = monitor.check_health()
    print(f"\nHealth Status: {health['overall_health']}")
    if health['issues']:
        print(f"  Issues: {health['issues']}")

    # Save state
    hal.save_state('hal_state.json')
    print("\nHAL state saved to hal_state.json")

    # Shutdown
    print("\nShutting down HAL...")
    hal.shutdown()

if __name__ == '__main__':
    main()