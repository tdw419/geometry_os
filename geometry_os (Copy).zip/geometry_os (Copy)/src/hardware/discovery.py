#!/usr/bin/env python3
"""
Hardware Discovery Module for Geometry OS
Scans the system to map physical hardware components
"""

import os
import json
import subprocess
import platform
from typing import Dict, List, Any, Optional
import re
from dataclasses import dataclass
import psutil  # For system information

@dataclass
class HardwareComponent:
    """Data class representing a hardware component"""
    component_type: str
    name: str
    vendor: str = "Unknown"
    device_id: str = "Unknown"
    bus_info: str = "Unknown"
    capabilities: List[str] = None
    driver: str = "Unknown"
    status: str = "detected"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return {
            'component_type': self.component_type,
            'name': self.name,
            'vendor': self.vendor,
            'device_id': self.device_id,
            'bus_info': self.bus_info,
            'capabilities': self.capabilities or [],
            'driver': self.driver,
            'status': self.status
        }

class HardwareDiscovery:
    """Main hardware discovery class"""

    def __init__(self):
        self.system_info = {
            'os': platform.system(),
            'os_version': platform.version(),
            'architecture': platform.machine(),
            'hostname': platform.node(),
            'kernel': platform.release()
        }
        self.components = []

    def scan_system(self) -> Dict[str, Any]:
        """Main scan method that discovers all hardware"""
        self._scan_cpu()
        self._scan_memory()
        self._scan_disks()
        self._scan_pci_devices()
        self._scan_usb_devices()
        self._scan_network_interfaces()

        return {
            'system_info': self.system_info,
            'components': [comp.to_dict() for comp in self.components],
            'timestamp': self._get_current_timestamp()
        }

    def _get_current_timestamp(self) -> str:
        """Get current timestamp"""
        from datetime import datetime
        return datetime.now().isoformat()

    def _scan_cpu(self):
        """Scan CPU information"""
        try:
            if platform.system() == 'Linux':
                # Read CPU info from /proc/cpuinfo
                with open('/proc/cpuinfo', 'r') as f:
                    cpu_info = f.read()

                # Parse CPU info
                model_name = self._extract_cpu_info(cpu_info, 'model name')
                vendor_id = self._extract_cpu_info(cpu_info, 'vendor_id')
                cpu_cores = self._count_cpu_cores(cpu_info)

                self.components.append(HardwareComponent(
                    component_type='cpu',
                    name=model_name or 'CPU',
                    vendor=vendor_id or 'Unknown',
                    capabilities=['processing', 'multicore'] if cpu_cores > 1 else ['processing']
                ))

            elif platform.system() == 'Windows':
                # Windows CPU detection
                import wmi
                c = wmi.WMI()
                for processor in c.Win32_Processor():
                    self.components.append(HardwareComponent(
                        component_type='cpu',
                        name=processor.Name,
                        vendor=processor.Manufacturer,
                        capabilities=['processing']
                    ))
        except Exception as e:
            print(f"Error scanning CPU: {e}")
            self.components.append(HardwareComponent(
                component_type='cpu',
                name='Unknown CPU',
                status='error'
            ))

    def _extract_cpu_info(self, cpu_info: str, field: str) -> Optional[str]:
        """Extract specific field from CPU info"""
        pattern = rf'{field}\s+:\s+(.*?)\n'
        match = re.search(pattern, cpu_info)
        return match.group(1).strip() if match else None

    def _count_cpu_cores(self, cpu_info: str) -> int:
        """Count CPU cores from /proc/cpuinfo"""
        return cpu_info.count('processor\t:')

    def _scan_memory(self):
        """Scan system memory"""
        try:
            if platform.system() == 'Linux':
                # Read memory info from /proc/meminfo
                with open('/proc/meminfo', 'r') as f:
                    mem_info = f.read()

                total_mem = self._extract_memory_value(mem_info, 'MemTotal')
                free_mem = self._extract_memory_value(mem_info, 'MemFree')

                self.components.append(HardwareComponent(
                    component_type='memory',
                    name='System Memory',
                    capabilities=['volatile_storage'],
                    vendor='System',
                    device_id=f'{total_mem}KB'
                ))

            # Use psutil as fallback
            mem = psutil.virtual_memory()
            self.components.append(HardwareComponent(
                component_type='memory',
                name='System Memory',
                capabilities=['volatile_storage'],
                vendor='System',
                device_id=f'{mem.total} bytes'
            ))
        except Exception as e:
            print(f"Error scanning memory: {e}")
            self.components.append(HardwareComponent(
                component_type='memory',
                name='Unknown Memory',
                status='error'
            ))

    def _extract_memory_value(self, mem_info: str, field: str) -> Optional[int]:
        """Extract memory value from meminfo"""
        pattern = rf'{field}:\s+(\d+)\s+kB'
        match = re.search(pattern, mem_info)
        return int(match.group(1)) if match else None

    def _scan_disks(self):
        """Scan disk drives"""
        try:
            partitions = psutil.disk_partitions()
            for partition in partitions:
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    self.components.append(HardwareComponent(
                        component_type='disk',
                        name=f'Disk {partition.device}',
                        vendor='Unknown',
                        device_id=partition.device,
                        capabilities=['storage', 'persistent'],
                        driver=partition.fstype or 'Unknown'
                    ))
                except Exception as e:
                    print(f"Error scanning disk {partition.device}: {e}")
                    continue
        except Exception as e:
            print(f"Error scanning disks: {e}")

    def _scan_pci_devices(self):
        """Scan PCI devices using lspci"""
        try:
            if platform.system() == 'Linux':
                result = subprocess.run(['lspci', '-vmm'], capture_output=True, text=True)
                if result.returncode == 0:
                    devices = self._parse_lspci_output(result.stdout)
                    for device in devices:
                        self.components.append(device)
                else:
                    print("lspci command failed, trying alternative method")
                    # Fallback to reading /sys/bus/pci/devices
                    self._scan_pci_sysfs()
            elif platform.system() == 'Windows':
                self._scan_pci_windows()
        except Exception as e:
            print(f"Error scanning PCI devices: {e}")

    def _parse_lspci_output(self, output: str) -> List[HardwareComponent]:
        """Parse lspci -vmm output"""
        devices = []
        current_device = None

        for line in output.split('\n'):
            if not line.strip():
                if current_device:
                    devices.append(current_device)
                    current_device = None
                continue

            if line.startswith('Slot:'):
                if current_device:
                    devices.append(current_device)
                current_device = HardwareComponent(
                    component_type='pci',
                    name='PCI Device'  # Default name, will be updated when Class: is found
                )
                current_device.bus_info = line.split(':', 1)[1].strip()
            elif line.startswith('Class:'):
                current_device.name = line.split(':', 1)[1].strip()
            elif line.startswith('Vendor:'):
                current_device.vendor = line.split(':', 1)[1].strip()
            elif line.startswith('Device:'):
                current_device.device_id = line.split(':', 1)[1].strip()
            elif line.startswith('Driver:'):
                current_device.driver = line.split(':', 1)[1].strip()

        if current_device:
            devices.append(current_device)

        return devices

    def _scan_pci_sysfs(self):
        """Scan PCI devices from /sys/bus/pci/devices"""
        try:
            pci_path = '/sys/bus/pci/devices'
            if os.path.exists(pci_path):
                for device_id in os.listdir(pci_path):
                    device_path = os.path.join(pci_path, device_id)
                    if os.path.isdir(device_path):
                        vendor = self._read_sysfs_file(os.path.join(device_path, 'vendor'))
                        device = self._read_sysfs_file(os.path.join(device_path, 'device'))
                        class_name = self._read_sysfs_file(os.path.join(device_path, 'class'))
                        driver = self._read_sysfs_file(os.path.join(device_path, 'driver'))

                        self.components.append(HardwareComponent(
                            component_type='pci',
                            name=class_name or f'PCI Device {device_id}',
                            vendor=vendor or 'Unknown',
                            device_id=device_id,
                            bus_info=device_id,
                            driver=driver or 'Unknown'
                        ))
        except Exception as e:
            print(f"Error scanning PCI devices from sysfs: {e}")

    def _read_sysfs_file(self, file_path: str) -> Optional[str]:
        """Read a file from sysfs"""
        try:
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    return f.read().strip()
        except Exception:
            return None
        return None

    def _scan_pci_windows(self):
        """Scan PCI devices on Windows"""
        try:
            import wmi
            c = wmi.WMI()
            for device in c.Win32_PnPEntity():
                if 'PCI' in str(device.Caption):
                    self.components.append(HardwareComponent(
                        component_type='pci',
                        name=device.Caption,
                        vendor=device.Manufacturer,
                        device_id=device.DeviceID,
                        bus_info=device.PNPDeviceID
                    ))
        except Exception as e:
            print(f"Error scanning PCI devices on Windows: {e}")

    def _scan_usb_devices(self):
        """Scan USB devices"""
        try:
            if platform.system() == 'Linux':
                result = subprocess.run(['lsusb'], capture_output=True, text=True)
                if result.returncode == 0:
                    self._parse_lsusb_output(result.stdout)
                else:
                    print("lsusb command failed, trying alternative method")
                    self._scan_usb_sysfs()
            elif platform.system() == 'Windows':
                self._scan_usb_windows()
        except Exception as e:
            print(f"Error scanning USB devices: {e}")

    def _parse_lsusb_output(self, output: str):
        """Parse lsusb output"""
        for line in output.split('\n'):
            if line.strip():
                parts = line.split()
                if len(parts) >= 6:
                    bus_id = parts[1]
                    device_id = parts[3]
                    vendor_product = parts[5].split(':')
                    if len(vendor_product) == 2:
                        vendor_id, product_id = vendor_product
                        # Remove the trailing 'i' from interface if present
                        if product_id.endswith('i'):
                            product_id = product_id[:-1]

                        # Get device description (rest of the line)
                        description = ' '.join(parts[6:])

                        self.components.append(HardwareComponent(
                            component_type='usb',
                            name=description,
                            vendor=f'USB Vendor {vendor_id}',
                            device_id=f'{vendor_id}:{product_id}',
                            bus_info=f'{bus_id}-{device_id}'
                        ))

    def _scan_usb_sysfs(self):
        """Scan USB devices from /sys/bus/usb/devices"""
        try:
            usb_path = '/sys/bus/usb/devices'
            if os.path.exists(usb_path):
                for device_id in os.listdir(usb_path):
                    device_path = os.path.join(usb_path, device_id)
                    if os.path.isdir(device_path) and device_id.startswith('usb'):
                        # Check if it's a USB device (not a bus)
                        if os.path.exists(os.path.join(device_path, 'manufacturer')):
                            manufacturer = self._read_sysfs_file(os.path.join(device_path, 'manufacturer'))
                            product = self._read_sysfs_file(os.path.join(device_path, 'product'))
                            serial = self._read_sysfs_file(os.path.join(device_path, 'serial'))

                            self.components.append(HardwareComponent(
                                component_type='usb',
                                name=product or f'USB Device {device_id}',
                                vendor=manufacturer or 'Unknown',
                                device_id=device_id,
                                bus_info=device_id
                            ))
        except Exception as e:
            print(f"Error scanning USB devices from sysfs: {e}")

    def _scan_usb_windows(self):
        """Scan USB devices on Windows"""
        try:
            import wmi
            c = wmi.WMI()
            for device in c.Win32_USBControllerDevice():
                self.components.append(HardwareComponent(
                    component_type='usb',
                    name=device.Dependent or 'USB Device',
                    vendor='Unknown',
                    device_id=device.Antecedent or 'Unknown'
                ))
        except Exception as e:
            print(f"Error scanning USB devices on Windows: {e}")

    def _scan_network_interfaces(self):
        """Scan network interfaces"""
        try:
            # Get network interfaces using psutil
            net_io = psutil.net_io_counters(pernic=True)
            for interface, stats in net_io.items():
                self.components.append(HardwareComponent(
                    component_type='network',
                    name=interface,
                    vendor='Unknown',
                    capabilities=['networking'],
                    device_id=interface
                ))
        except Exception as e:
            print(f"Error scanning network interfaces: {e}")

    def get_hardware_json(self) -> str:
        """Get hardware information as JSON string"""
        scan_result = self.scan_system()
        return json.dumps(scan_result, indent=2)

    def save_hardware_profile(self, file_path: str):
        """Save hardware profile to file"""
        hardware_json = self.get_hardware_json()
        with open(file_path, 'w') as f:
            f.write(hardware_json)

    def load_hardware_profile(self, file_path: str) -> Dict[str, Any]:
        """Load hardware profile from file"""
        with open(file_path, 'r') as f:
            return json.load(f)

def discover_hardware() -> Dict[str, Any]:
    """Convenience function to discover hardware"""
    discovery = HardwareDiscovery()
    return discovery.scan_system()

def main():
    """Main function for testing"""
    print("Starting hardware discovery...")
    discovery = HardwareDiscovery()
    hardware_data = discovery.scan_system()

    # Print summary
    print(f"\nDiscovered {len(hardware_data['components'])} hardware components")
    print(f"System: {hardware_data['system_info']['os']} {hardware_data['system_info']['architecture']}")

    # Save to file
    discovery.save_hardware_profile('hardware_profile.json')
    print("Hardware profile saved to hardware_profile.json")

if __name__ == '__main__':
    main()