# Hardware package initialization
# This package contains hardware discovery and driver components for Geometry OS