#!/usr/bin/env python3
"""
Specialized Network Driver for Geometry OS
Provides real-time network bandwidth monitoring and statistics
"""

import time
import psutil
import platform
from typing import Dict, Any, List, Optional
import logging
from dataclasses import dataclass
import json

# Local imports
from hardware.drivers.neural_driver_base import NeuralDriverBase, DriverCapability, DriverMetadata

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class NetworkStats:
    """Data class for network statistics"""
    bytes_sent: int = 0
    bytes_recv: int = 0
    packets_sent: int = 0
    packets_recv: int = 0
    errors_in: int = 0
    errors_out: int = 0
    drop_in: int = 0
    drop_out: int = 0
    timestamp: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'bytes_sent': self.bytes_sent,
            'bytes_recv': self.bytes_recv,
            'packets_sent': self.packets_sent,
            'packets_recv': self.packets_recv,
            'errors_in': self.errors_in,
            'errors_out': self.errors_out,
            'drop_in': self.drop_in,
            'drop_out': self.drop_out,
            'timestamp': self.timestamp
        }

class NetworkNeuralDriver(NeuralDriverBase):
    """Specialized neural driver for network hardware"""

    def __init__(self, component_info: Dict[str, Any]):
        super().__init__(component_info)

        # Network-specific attributes
        # Network-specific attributes
        self.network_stats = NetworkStats()
        self.last_read_time = 0
        self.read_interval = 1.0  # Minimum 1 second between reads
        self.interface_name = self.component_info.get('device_id', '')
        self.network_info = self._get_network_info()

        # Update metadata
        self.metadata = self._get_metadata()

        # Add network-specific capabilities
        self.capabilities.extend([
            DriverCapability.READ,
            DriverCapability.MONITOR,
            DriverCapability.CONTROL
        ])

    def _get_metadata(self) -> DriverMetadata:
        """Get network driver metadata"""
        return DriverMetadata(
            name="NetworkNeuralDriver",
            version="1.0.0",
            author="Geometry OS",
            description=f"Specialized neural driver for {self.component_info.get('name', 'Network Interface')}",
            supported_platforms=["Linux", "Windows", "Darwin"],
            dependencies=["psutil"]
        )

    def _get_network_info(self) -> Dict[str, Any]:
        """Get detailed network information"""
        info = {
            'interface': self.interface_name,
            'os': platform.system(),
            'architecture': platform.machine()
        }

        # Get interface addresses
        try:
            addrs = psutil.net_if_addrs()
            if self.interface_name in addrs:
                for addr in addrs[self.interface_name]:
                    if addr.family == psutil.AF_INET:
                        info['ipv4'] = addr.address
                        info['netmask'] = addr.netmask
                        if hasattr(addr, 'broadcast'):
                            info['broadcast'] = addr.broadcast
                    elif addr.family == psutil.AF_INET6:
                        info['ipv6'] = addr.address
        except Exception as e:
            self.logger.debug(f"Could not get network addresses: {e}")

        return info

    def initialize(self) -> bool:
        """Initialize the network driver"""
        try:
            self.state = self.state.INITIALIZING
            self.logger.info(f"Initializing network driver for {self.component_info.get('name', 'Network Interface')}")

            # Validate component
            self._validate_component()

            # Get initial network stats
            self._read_network_stats()

            self.state = self.state.READY
            self.is_initialized = True
            self.logger.info("Network driver initialized successfully")
            return True

        except Exception as e:
            self.set_error(e)
            self.logger.error(f"Failed to initialize network driver: {str(e)}")
            return False

    def _read_network_stats(self) -> NetworkStats:
        """Read current network statistics"""
        try:
            # Rate limit reads
            current_time = time.time()
            if current_time - self.last_read_time < self.read_interval:
                return self.network_stats

            if not self.interface_name:
                self.logger.warning(f"No interface name found for network device")
                return self.network_stats

            # Get network I/O stats
            io_stats = psutil.net_io_counters(pernic=True)
            if self.interface_name not in io_stats:
                self.logger.warning(f"Interface {self.interface_name} not found in network stats")
                return self.network_stats

            net_io = io_stats[self.interface_name]

            stats = NetworkStats(
                bytes_sent=net_io.bytes_sent,
                bytes_recv=net_io.bytes_recv,
                packets_sent=net_io.packets_sent,
                packets_recv=net_io.packets_recv,
                errors_in=net_io.errin,
                errors_out=net_io.errout,
                drop_in=net_io.dropin,
                drop_out=net_io.dropout,
                timestamp=time.time()
            )

            self.network_stats = stats
            self.last_read_time = current_time
            return stats

        except Exception as e:
            self.logger.error(f"Error reading network stats: {str(e)}")
            return self.network_stats

    def get_current_stats(self) -> NetworkStats:
        """Get current network statistics"""
        if not self.is_operational():
            raise RuntimeError("Network driver is not operational")

        return self._read_network_stats()

    def get_bandwidth(self, interval: float = 1.0) -> Dict[str, float]:
        """Get current bandwidth usage in bytes per second"""
        if not self.is_operational():
            raise RuntimeError("Network driver is not operational")

        # Get current stats
        current_stats = self.get_current_stats()
        time.sleep(interval)
        new_stats = self.get_current_stats()

        # Calculate bandwidth
        bytes_sent_per_sec = (new_stats.bytes_sent - current_stats.bytes_sent) / interval
        bytes_recv_per_sec = (new_stats.bytes_recv - current_stats.bytes_recv) / interval

        return {
            'bytes_sent_per_sec': bytes_sent_per_sec,
            'bytes_recv_per_sec': bytes_recv_per_sec,
            'total_per_sec': bytes_sent_per_sec + bytes_recv_per_sec
        }

    def get_network_info(self) -> Dict[str, Any]:
        """Get detailed network information"""
        if not self.is_operational():
            raise RuntimeError("Network driver is not operational")

        return self.network_info

    def get_health_status(self) -> Dict[str, Any]:
        """Get network health status"""
        if not self.is_operational():
            raise RuntimeError("Network driver is not operational")

        stats = self.get_current_stats()
        health = {
            'status': 'good',
            'error_level': 'none',
            'drop_level': 'none',
            'issues': []
        }

        # Analyze errors
        total_errors = stats.errors_in + stats.errors_out
        if total_errors > 100:
            health['error_level'] = 'critical'
            health['issues'].append('high_network_errors')
        elif total_errors > 50:
            health['error_level'] = 'high'
        elif total_errors > 10:
            health['error_level'] = 'medium'

        # Analyze drops
        total_drops = stats.drop_in + stats.drop_out
        if total_drops > 100:
            health['drop_level'] = 'critical'
            health['issues'].append('high_network_drops')
        elif total_drops > 50:
            health['drop_level'] = 'high'
        elif total_drops > 10:
            health['drop_level'] = 'medium'

        if health['issues']:
            health['status'] = 'warning' if len(health['issues']) == 1 else 'critical'

        return health

    def read_status(self) -> Dict[str, Any]:
        """Read network status"""
        if not self.is_operational():
            raise RuntimeError("Network driver is not operational")

        stats = self.get_current_stats()
        health = self.get_health_status()

        return {
            'status': 'operational',
            'component': self.component_info.get('name'),
            'type': self.component_info.get('component_type'),
            'bytes_sent': stats.bytes_sent,
            'bytes_recv': stats.bytes_recv,
            'packets_sent': stats.packets_sent,
            'packets_recv': stats.packets_recv,
            'errors_in': stats.errors_in,
            'errors_out': stats.errors_out,
            'drops_in': stats.drop_in,
            'drops_out': stats.drop_out,
            'health': health,
            'capabilities': [cap.name for cap in self.capabilities]
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert driver to dictionary with network-specific data"""
        base_dict = super().to_dict()
        base_dict.update({
            'network_info': self.network_info,
            'current_stats': self.network_stats.to_dict(),
            'driver_type': 'network'
        })
        return base_dict

    def shutdown(self) -> bool:
        """Shutdown the network driver"""
        try:
            self.state = self.state.DISABLED
            self.logger.info("Network driver shutdown successfully")
            return True
        except Exception as e:
            self.set_error(e)
            self.logger.error(f"Failed to shutdown network driver: {str(e)}")
            return False

def create_network_driver(component_info: Dict[str, Any]) -> NetworkNeuralDriver:
    """Create a network neural driver instance"""
    return NetworkNeuralDriver(component_info)

def main():
    """Test the network driver"""
    # Example component info
    example_component = {
        'component_type': 'network',
        'name': 'Ethernet Interface',
        'vendor': 'Intel',
        'device_id': 'eth0',
        'capabilities': ['networking']
    }

    print("Creating network neural driver...")
    driver = create_network_driver(example_component)

    print(f"Driver metadata: {driver.get_metadata()}")
    print(f"Driver capabilities: {[cap.name for cap in driver.get_capabilities()]}")

    print("Initializing driver...")
    if driver.initialize():
        print("Driver initialized successfully")
        print(f"Driver state: {driver.get_state()}")

        # Test network monitoring
        stats = driver.get_current_stats()
        print(f"\nNetwork Statistics:")
        print(f"  Bytes Sent: {round(stats.bytes_sent / (1024 ** 2), 2)} MB")
        print(f"  Bytes Received: {round(stats.bytes_recv / (1024 ** 2), 2)} MB")
        print(f"  Packets Sent: {stats.packets_sent}")
        print(f"  Packets Received: {stats.packets_recv}")
        print(f"  Errors: {stats.errors_in + stats.errors_out}")
        print(f"  Drops: {stats.drop_in + stats.drop_out}")

        # Test bandwidth
        bandwidth = driver.get_bandwidth(0.5)  # Short interval for testing
        print(f"\nBandwidth (last 0.5s):")
        print(f"  Sent: {round(bandwidth['bytes_sent_per_sec'] / (1024 ** 2), 2)} MB/s")
        print(f"  Received: {round(bandwidth['bytes_recv_per_sec'] / (1024 ** 2), 2)} MB/s")
        print(f"  Total: {round(bandwidth['total_per_sec'] / (1024 ** 2), 2)} MB/s")

        # Test health status
        health = driver.get_health_status()
        print(f"\nNetwork Health:")
        print(f"  Status: {health['status']}")
        print(f"  Error Level: {health['error_level']}")
        print(f"  Drop Level: {health['drop_level']}")
        if health['issues']:
            print(f"  Issues: {health['issues']}")

        # Test full status
        status = driver.read_status()
        print(f"\nFull Network Status:")
        print(f"  Component: {status['component']}")
        print(f"  Health: {status['health']['status']}")

        # Shutdown
        print("\nShutting down driver...")
        driver.shutdown()
    else:
        print("Failed to initialize driver")

if __name__ == '__main__':
    main()