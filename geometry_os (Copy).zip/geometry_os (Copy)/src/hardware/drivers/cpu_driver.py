#!/usr/bin/env python3
"""
Specialized CPU Driver for Geometry OS
Provides real-time CPU load, frequency, and temperature monitoring
"""

import time
import psutil
import platform
from typing import Dict, Any, List, Optional
import logging
from dataclasses import dataclass
import json
import os
import re

# Local imports
from hardware.drivers.neural_driver_base import NeuralDriverBase, DriverCapability, DriverMetadata

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class CPUStats:
    """Data class for CPU statistics"""
    load_percent: float = 0.0
    frequency_mhz: float = 0.0
    temperature_celsius: Optional[float] = None
    cores: int = 1
    logical_cores: int = 1
    usage_per_core: List[float] = None
    timestamp: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'load_percent': self.load_percent,
            'frequency_mhz': self.frequency_mhz,
            'temperature_celsius': self.temperature_celsius,
            'cores': self.cores,
            'logical_cores': self.logical_cores,
            'usage_per_core': self.usage_per_core or [],
            'timestamp': self.timestamp
        }

class CPUNeuralDriver(NeuralDriverBase):
    """Specialized neural driver for CPU hardware"""

    def __init__(self, component_info: Dict[str, Any]):
        super().__init__(component_info)

        # CPU-specific attributes
        self.cpu_stats = CPUStats()
        self.last_read_time = 0
        self.read_interval = 1.0  # Minimum 1 second between reads
        self.cpu_info = self._get_cpu_info()

        # Update metadata
        self.metadata = self._get_metadata()

        # Add CPU-specific capabilities
        self.capabilities.extend([
            DriverCapability.READ,
            DriverCapability.MONITOR,
            DriverCapability.CONTROL
        ])

    def _get_metadata(self) -> DriverMetadata:
        """Get CPU driver metadata"""
        return DriverMetadata(
            name="CPUNeuralDriver",
            version="1.0.0",
            author="Geometry OS",
            description=f"Specialized neural driver for {self.component_info.get('name', 'CPU')}",
            supported_platforms=["Linux", "Windows", "Darwin"],
            dependencies=["psutil"]
        )

    def _get_cpu_info(self) -> Dict[str, Any]:
        """Get detailed CPU information"""
        info = {
            'physical_cores': psutil.cpu_count(logical=False) or 1,
            'logical_cores': psutil.cpu_count(logical=True) or 1,
            'vendor': self.component_info.get('vendor', 'Unknown'),
            'model': self.component_info.get('name', 'Unknown CPU'),
            'architecture': platform.machine(),
            'os': platform.system()
        }

        # Get CPU frequency info
        try:
            freq = psutil.cpu_freq()
            if freq:
                info['min_frequency'] = freq.min
                info['max_frequency'] = freq.max
                info['current_frequency'] = freq.current
        except Exception as e:
            logger.debug(f"Could not get CPU frequency: {e}")

        return info

    def initialize(self) -> bool:
        """Initialize the CPU driver"""
        try:
            self.state = self.state.INITIALIZING
            self.logger.info(f"Initializing CPU driver for {self.component_info.get('name', 'CPU')}")

            # Validate component
            self._validate_component()

            # Get initial CPU stats
            self._read_cpu_stats()

            self.state = self.state.READY
            self.is_initialized = True
            self.logger.info("CPU driver initialized successfully")
            return True

        except Exception as e:
            self.set_error(e)
            self.logger.error(f"Failed to initialize CPU driver: {str(e)}")
            return False

    def _read_cpu_stats(self) -> CPUStats:
        """Read current CPU statistics"""
        try:
            # Rate limit reads
            current_time = time.time()
            if current_time - self.last_read_time < self.read_interval:
                return self.cpu_stats

            # Update CPU stats
            cpu_load = psutil.cpu_percent(interval=None, percpu=True)
            cpu_freq = psutil.cpu_freq()

            stats = CPUStats(
                load_percent=psutil.cpu_percent(interval=None),
                frequency_mhz=cpu_freq.current if cpu_freq else 0.0,
                temperature_celsius=self._read_cpu_temperature(),
                cores=self.cpu_info['physical_cores'],
                logical_cores=self.cpu_info['logical_cores'],
                usage_per_core=cpu_load,
                timestamp=time.time()
            )

            self.cpu_stats = stats
            self.last_read_time = current_time
            return stats

        except Exception as e:
            self.logger.error(f"Error reading CPU stats: {str(e)}")
            return self.cpu_stats

    def _read_cpu_temperature(self) -> Optional[float]:
        """Read CPU temperature (platform-specific)"""
        try:
            if platform.system() == 'Linux':
                # Try common thermal zones
                for zone in ['thermal_zone0', 'thermal_zone1', 'thermal_zone2']:
                    try:
                        with open(f'/sys/class/thermal/{zone}/temp', 'r') as f:
                            temp_millidegrees = int(f.read().strip())
                            return temp_millidegrees / 1000.0
                    except Exception:
                        continue

                # Try alternative locations
                try:
                    with open('/sys/class/hwmon/hwmon0/temp1_input', 'r') as f:
                        temp_millidegrees = int(f.read().strip())
                        return temp_millidegrees / 1000.0
                except Exception:
                    pass

            elif platform.system() == 'Windows':
                # Windows temperature reading (requires additional libraries)
                try:
                    import wmi
                    w = wmi.WMI(namespace="root\\OpenHardwareMonitor")
                    temperature_infos = w.Sensor()
                    for sensor in temperature_infos:
                        if sensor.SensorType == 'Temperature' and 'CPU' in sensor.Name:
                            return sensor.Value
                except Exception:
                    pass

            elif platform.system() == 'Darwin':
                # macOS temperature reading
                try:
                    import subprocess
                    result = subprocess.run(['istats', 'cpu', 'temp', '--json'],
                                          capture_output=True, text=True)
                    if result.returncode == 0:
                        data = json.loads(result.stdout)
                        return data.get('temperature', 0.0)
                except Exception:
                    pass

        except Exception as e:
            self.logger.debug(f"Could not read CPU temperature: {e}")

        return None

    def get_current_stats(self) -> CPUStats:
        """Get current CPU statistics"""
        if not self.is_operational():
            raise RuntimeError("CPU driver is not operational")

        return self._read_cpu_stats()

    def get_average_load(self, duration: float = 1.0) -> float:
        """Get average CPU load over duration"""
        if not self.is_operational():
            raise RuntimeError("CPU driver is not operational")

        # For simplicity, return current load
        # In a production system, this would track load over time
        return self.get_current_stats().load_percent

    def get_temperature(self) -> Optional[float]:
        """Get current CPU temperature in Celsius"""
        if not self.is_operational():
            raise RuntimeError("CPU driver is not operational")

        return self.get_current_stats().temperature_celsius

    def get_frequency(self) -> float:
        """Get current CPU frequency in MHz"""
        if not self.is_operational():
            raise RuntimeError("CPU driver is not operational")

        return self.get_current_stats().frequency_mhz

    def get_usage_per_core(self) -> List[float]:
        """Get CPU usage per core"""
        if not self.is_operational():
            raise RuntimeError("CPU driver is not operational")

        stats = self.get_current_stats()
        return stats.usage_per_core or []

    def get_cpu_info(self) -> Dict[str, Any]:
        """Get detailed CPU information"""
        if not self.is_operational():
            raise RuntimeError("CPU driver is not operational")

        return self.cpu_info

    def get_health_status(self) -> Dict[str, Any]:
        """Get CPU health status"""
        if not self.is_operational():
            raise RuntimeError("CPU driver is not operational")

        stats = self.get_current_stats()
        health = {
            'status': 'good',
            'load_level': 'normal',
            'temperature_level': 'normal',
            'issues': []
        }

        # Analyze load
        if stats.load_percent > 90:
            health['load_level'] = 'high'
            health['issues'].append('high_cpu_load')
        elif stats.load_percent > 75:
            health['load_level'] = 'medium'

        # Analyze temperature (if available)
        if stats.temperature_celsius is not None:
            if stats.temperature_celsius > 90:
                health['temperature_level'] = 'critical'
                health['issues'].append('high_cpu_temperature')
            elif stats.temperature_celsius > 80:
                health['temperature_level'] = 'high'
            elif stats.temperature_celsius > 70:
                health['temperature_level'] = 'medium'

        if health['issues']:
            health['status'] = 'warning' if len(health['issues']) == 1 else 'critical'

        return health

    def read_status(self) -> Dict[str, Any]:
        """Read CPU status"""
        if not self.is_operational():
            raise RuntimeError("CPU driver is not operational")

        stats = self.get_current_stats()
        health = self.get_health_status()

        return {
            'status': 'operational',
            'component': self.component_info.get('name'),
            'type': self.component_info.get('component_type'),
            'load_percent': stats.load_percent,
            'frequency_mhz': stats.frequency_mhz,
            'temperature_celsius': stats.temperature_celsius,
            'cores': stats.cores,
            'logical_cores': stats.logical_cores,
            'health': health,
            'capabilities': [cap.name for cap in self.capabilities]
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert driver to dictionary with CPU-specific data"""
        base_dict = super().to_dict()
        base_dict.update({
            'cpu_info': self.cpu_info,
            'current_stats': self.cpu_stats.to_dict(),
            'driver_type': 'cpu'
        })
        return base_dict

    def shutdown(self) -> bool:
        """Shutdown the CPU driver"""
        try:
            self.state = self.state.DISABLED
            self.logger.info("CPU driver shutdown successfully")
            return True
        except Exception as e:
            self.set_error(e)
            self.logger.error(f"Failed to shutdown CPU driver: {str(e)}")
            return False

def create_cpu_driver(component_info: Dict[str, Any]) -> CPUNeuralDriver:
    """Create a CPU neural driver instance"""
    return CPUNeuralDriver(component_info)

def main():
    """Test the CPU driver"""
    # Example component info
    example_component = {
        'component_type': 'cpu',
        'name': 'Intel Core i7',
        'vendor': 'Intel',
        'device_id': 'cpu0',
        'capabilities': ['processing', 'multicore']
    }

    print("Creating CPU neural driver...")
    driver = create_cpu_driver(example_component)

    print(f"Driver metadata: {driver.get_metadata()}")
    print(f"Driver capabilities: {[cap.name for cap in driver.get_capabilities()]}")

    print("Initializing driver...")
    if driver.initialize():
        print("Driver initialized successfully")
        print(f"Driver state: {driver.get_state()}")

        # Test CPU monitoring
        stats = driver.get_current_stats()
        print(f"\nCPU Statistics:")
        print(f"  Load: {stats.load_percent:.1f}%")
        print(f"  Frequency: {stats.frequency_mhz:.1f} MHz")
        print(f"  Temperature: {stats.temperature_celsius}°C" if stats.temperature_celsius else "  Temperature: Not available")
        print(f"  Cores: {stats.cores} physical, {stats.logical_cores} logical")
        print(f"  Per-core usage: {stats.usage_per_core}")

        # Test health status
        health = driver.get_health_status()
        print(f"\nCPU Health:")
        print(f"  Status: {health['status']}")
        print(f"  Load Level: {health['load_level']}")
        print(f"  Temperature Level: {health['temperature_level']}")
        if health['issues']:
            print(f"  Issues: {health['issues']}")

        # Test full status
        status = driver.read_status()
        print(f"\nFull CPU Status:")
        print(f"  Component: {status['component']}")
        print(f"  Load: {status['load_percent']}%")
        print(f"  Health: {status['health']['status']}")

        # Shutdown
        print("\nShutting down driver...")
        driver.shutdown()
    else:
        print("Failed to initialize driver")

if __name__ == '__main__':
    main()