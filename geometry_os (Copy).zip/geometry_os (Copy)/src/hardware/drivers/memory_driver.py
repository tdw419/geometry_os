#!/usr/bin/env python3
"""
Specialized Memory Driver for Geometry OS
Provides real-time memory usage tracking and analysis
"""

import time
import psutil
import platform
from typing import Dict, Any, List, Optional
import logging
from dataclasses import dataclass
import json

# Local imports
from hardware.drivers.neural_driver_base import NeuralDriverBase, DriverCapability, DriverMetadata

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class MemoryStats:
    """Data class for memory statistics"""
    total_bytes: int = 0
    available_bytes: int = 0
    used_bytes: int = 0
    free_bytes: int = 0
    percent_used: float = 0.0
    swap_total_bytes: int = 0
    swap_used_bytes: int = 0
    swap_free_bytes: int = 0
    swap_percent_used: float = 0.0
    timestamp: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'total_bytes': self.total_bytes,
            'available_bytes': self.available_bytes,
            'used_bytes': self.used_bytes,
            'free_bytes': self.free_bytes,
            'percent_used': self.percent_used,
            'swap_total_bytes': self.swap_total_bytes,
            'swap_used_bytes': self.swap_used_bytes,
            'swap_free_bytes': self.swap_free_bytes,
            'swap_percent_used': self.swap_percent_used,
            'timestamp': self.timestamp
        }

class MemoryNeuralDriver(NeuralDriverBase):
    """Specialized neural driver for memory hardware"""

    def __init__(self, component_info: Dict[str, Any]):
        super().__init__(component_info)

        # Memory-specific attributes
        self.memory_stats = MemoryStats()
        self.last_read_time = 0
        self.read_interval = 1.0  # Minimum 1 second between reads
        self.memory_info = self._get_memory_info()

        # Update metadata
        self.metadata = self._get_metadata()

        # Add memory-specific capabilities
        self.capabilities.extend([
            DriverCapability.READ,
            DriverCapability.MONITOR,
            DriverCapability.CONTROL
        ])

    def _get_metadata(self) -> DriverMetadata:
        """Get memory driver metadata"""
        return DriverMetadata(
            name="MemoryNeuralDriver",
            version="1.0.0",
            author="Geometry OS",
            description=f"Specialized neural driver for {self.component_info.get('name', 'Memory')}",
            supported_platforms=["Linux", "Windows", "Darwin"],
            dependencies=["psutil"]
        )

    def _get_memory_info(self) -> Dict[str, Any]:
        """Get detailed memory information"""
        info = {
            'total_memory_gb': round(psutil.virtual_memory().total / (1024 ** 3), 2),
            'os': platform.system(),
            'architecture': platform.machine()
        }

        return info

    def initialize(self) -> bool:
        """Initialize the memory driver"""
        try:
            self.state = self.state.INITIALIZING
            self.logger.info(f"Initializing memory driver for {self.component_info.get('name', 'Memory')}")

            # Validate component
            self._validate_component()

            # Get initial memory stats
            self._read_memory_stats()

            self.state = self.state.READY
            self.is_initialized = True
            self.logger.info("Memory driver initialized successfully")
            return True

        except Exception as e:
            self.set_error(e)
            self.logger.error(f"Failed to initialize memory driver: {str(e)}")
            return False

    def _read_memory_stats(self) -> MemoryStats:
        """Read current memory statistics"""
        try:
            # Rate limit reads
            current_time = time.time()
            if current_time - self.last_read_time < self.read_interval:
                return self.memory_stats

            # Get virtual memory stats
            virt_mem = psutil.virtual_memory()
            swap_mem = psutil.swap_memory()

            stats = MemoryStats(
                total_bytes=virt_mem.total,
                available_bytes=virt_mem.available,
                used_bytes=virt_mem.used,
                free_bytes=virt_mem.free,
                percent_used=virt_mem.percent,
                swap_total_bytes=swap_mem.total,
                swap_used_bytes=swap_mem.used,
                swap_free_bytes=swap_mem.free,
                swap_percent_used=swap_mem.percent,
                timestamp=time.time()
            )

            self.memory_stats = stats
            self.last_read_time = current_time
            return stats

        except Exception as e:
            self.logger.error(f"Error reading memory stats: {str(e)}")
            return self.memory_stats

    def get_current_stats(self) -> MemoryStats:
        """Get current memory statistics"""
        if not self.is_operational():
            raise RuntimeError("Memory driver is not operational")

        return self._read_memory_stats()

    def get_memory_usage(self) -> float:
        """Get current memory usage percentage"""
        if not self.is_operational():
            raise RuntimeError("Memory driver is not operational")

        return self.get_current_stats().percent_used

    def get_swap_usage(self) -> float:
        """Get current swap usage percentage"""
        if not self.is_operational():
            raise RuntimeError("Memory driver is not operational")

        return self.get_current_stats().swap_percent_used

    def get_memory_info(self) -> Dict[str, Any]:
        """Get detailed memory information"""
        if not self.is_operational():
            raise RuntimeError("Memory driver is not operational")

        return self.memory_info

    def get_health_status(self) -> Dict[str, Any]:
        """Get memory health status"""
        if not self.is_operational():
            raise RuntimeError("Memory driver is not operational")

        stats = self.get_current_stats()
        health = {
            'status': 'good',
            'memory_level': 'normal',
            'swap_level': 'normal',
            'issues': []
        }

        # Analyze memory usage
        if stats.percent_used > 90:
            health['memory_level'] = 'critical'
            health['issues'].append('high_memory_usage')
        elif stats.percent_used > 80:
            health['memory_level'] = 'high'
        elif stats.percent_used > 70:
            health['memory_level'] = 'medium'

        # Analyze swap usage
        if stats.swap_percent_used > 80:
            health['swap_level'] = 'high'
            health['issues'].append('high_swap_usage')
        elif stats.swap_percent_used > 60:
            health['swap_level'] = 'medium'

        if health['issues']:
            health['status'] = 'warning' if len(health['issues']) == 1 else 'critical'

        return health

    def read_status(self) -> Dict[str, Any]:
        """Read memory status"""
        if not self.is_operational():
            raise RuntimeError("Memory driver is not operational")

        stats = self.get_current_stats()
        health = self.get_health_status()

        return {
            'status': 'operational',
            'component': self.component_info.get('name'),
            'type': self.component_info.get('component_type'),
            'memory_usage_percent': stats.percent_used,
            'swap_usage_percent': stats.swap_percent_used,
            'total_memory_gb': round(stats.total_bytes / (1024 ** 3), 2),
            'used_memory_gb': round(stats.used_bytes / (1024 ** 3), 2),
            'free_memory_gb': round(stats.free_bytes / (1024 ** 3), 2),
            'health': health,
            'capabilities': [cap.name for cap in self.capabilities]
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert driver to dictionary with memory-specific data"""
        base_dict = super().to_dict()
        base_dict.update({
            'memory_info': self.memory_info,
            'current_stats': self.memory_stats.to_dict(),
            'driver_type': 'memory'
        })
        return base_dict

    def shutdown(self) -> bool:
        """Shutdown the memory driver"""
        try:
            self.state = self.state.DISABLED
            self.logger.info("Memory driver shutdown successfully")
            return True
        except Exception as e:
            self.set_error(e)
            self.logger.error(f"Failed to shutdown memory driver: {str(e)}")
            return False

def create_memory_driver(component_info: Dict[str, Any]) -> MemoryNeuralDriver:
    """Create a memory neural driver instance"""
    return MemoryNeuralDriver(component_info)

def main():
    """Test the memory driver"""
    # Example component info
    example_component = {
        'component_type': 'memory',
        'name': 'System Memory',
        'vendor': 'System',
        'device_id': 'mem0',
        'capabilities': ['volatile_storage']
    }

    print("Creating memory neural driver...")
    driver = create_memory_driver(example_component)

    print(f"Driver metadata: {driver.get_metadata()}")
    print(f"Driver capabilities: {[cap.name for cap in driver.get_capabilities()]}")

    print("Initializing driver...")
    if driver.initialize():
        print("Driver initialized successfully")
        print(f"Driver state: {driver.get_state()}")

        # Test memory monitoring
        stats = driver.get_current_stats()
        print(f"\nMemory Statistics:")
        print(f"  Total: {round(stats.total_bytes / (1024 ** 3), 2)} GB")
        print(f"  Used: {round(stats.used_bytes / (1024 ** 3), 2)} GB ({stats.percent_used:.1f}%)")
        print(f"  Free: {round(stats.free_bytes / (1024 ** 3), 2)} GB")
        print(f"  Swap Used: {round(stats.swap_used_bytes / (1024 ** 3), 2)} GB ({stats.swap_percent_used:.1f}%)")

        # Test health status
        health = driver.get_health_status()
        print(f"\nMemory Health:")
        print(f"  Status: {health['status']}")
        print(f"  Memory Level: {health['memory_level']}")
        print(f"  Swap Level: {health['swap_level']}")
        if health['issues']:
            print(f"  Issues: {health['issues']}")

        # Test full status
        status = driver.read_status()
        print(f"\nFull Memory Status:")
        print(f"  Component: {status['component']}")
        print(f"  Memory Usage: {status['memory_usage_percent']}%")
        print(f"  Health: {status['health']['status']}")

        # Shutdown
        print("\nShutting down driver...")
        driver.shutdown()
    else:
        print("Failed to initialize driver")

if __name__ == '__main__':
    main()