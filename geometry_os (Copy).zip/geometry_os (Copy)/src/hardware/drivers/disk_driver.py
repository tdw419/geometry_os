#!/usr/bin/env python3
"""
Specialized Disk Driver for Geometry OS
Provides real-time disk space monitoring and I/O statistics
"""

import time
import psutil
import platform
from typing import Dict, Any, List, Optional
import logging
from dataclasses import dataclass
import json
import os

# Local imports
from hardware.drivers.neural_driver_base import NeuralDriverBase, DriverCapability, DriverMetadata

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class DiskStats:
    """Data class for disk statistics"""
    total_bytes: int = 0
    used_bytes: int = 0
    free_bytes: int = 0
    percent_used: float = 0.0
    read_count: int = 0
    write_count: int = 0
    read_bytes: int = 0
    write_bytes: int = 0
    timestamp: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'total_bytes': self.total_bytes,
            'used_bytes': self.used_bytes,
            'free_bytes': self.free_bytes,
            'percent_used': self.percent_used,
            'read_count': self.read_count,
            'write_count': self.write_count,
            'read_bytes': self.read_bytes,
            'write_bytes': self.write_bytes,
            'timestamp': self.timestamp
        }

class DiskNeuralDriver(NeuralDriverBase):
    """Specialized neural driver for disk hardware"""

    def __init__(self, component_info: Dict[str, Any]):
        super().__init__(component_info)

        # Disk-specific attributes
        self.disk_stats = DiskStats()
        self.last_read_time = 0
        self.read_interval = 2.0  # Minimum 2 seconds between reads
        self.disk_info = self._get_disk_info()
        self.mount_point = self._get_mount_point()

        # Update metadata
        self.metadata = self._get_metadata()

        # Add disk-specific capabilities
        self.capabilities.extend([
            DriverCapability.READ,
            DriverCapability.MONITOR,
            DriverCapability.CONTROL
        ])

    def _get_metadata(self) -> DriverMetadata:
        """Get disk driver metadata"""
        return DriverMetadata(
            name="DiskNeuralDriver",
            version="1.0.0",
            author="Geometry OS",
            description=f"Specialized neural driver for {self.component_info.get('name', 'Disk')}",
            supported_platforms=["Linux", "Windows", "Darwin"],
            dependencies=["psutil"]
        )

    def _get_disk_info(self) -> Dict[str, Any]:
        """Get detailed disk information"""
        device_id = self.component_info.get('device_id', 'unknown')
        info = {
            'device': device_id,
            'mount_point': self._get_mount_point(),
            'filesystem': self.component_info.get('driver', 'unknown'),
            'os': platform.system()
        }

        return info

    def _get_mount_point(self) -> Optional[str]:
        """Get mount point for this disk"""
        device_id = self.component_info.get('device_id', '')
        if not device_id:
            return None

        try:
            partitions = psutil.disk_partitions()
            for partition in partitions:
                if partition.device == device_id:
                    return partition.mountpoint
        except Exception as e:
            self.logger.debug(f"Could not find mount point for {device_id}: {e}")

        return None

    def initialize(self) -> bool:
        """Initialize the disk driver"""
        try:
            self.state = self.state.INITIALIZING
            self.logger.info(f"Initializing disk driver for {self.component_info.get('name', 'Disk')}")

            # Validate component
            self._validate_component()

            # Get initial disk stats
            self._read_disk_stats()

            self.state = self.state.READY
            self.is_initialized = True
            self.logger.info("Disk driver initialized successfully")
            return True

        except Exception as e:
            self.set_error(e)
            self.logger.error(f"Failed to initialize disk driver: {str(e)}")
            return False

    def _read_disk_stats(self) -> DiskStats:
        """Read current disk statistics"""
        try:
            # Rate limit reads
            current_time = time.time()
            if current_time - self.last_read_time < self.read_interval:
                return self.disk_stats

            if not self.mount_point:
                self.logger.warning(f"No mount point found for disk {self.component_info.get('device_id')}")
                return self.disk_stats

            # Get disk usage
            usage = psutil.disk_usage(self.mount_point)

            # Get disk I/O stats
            io_stats = psutil.disk_io_counters(perdisk=True)
            disk_io = io_stats.get(self.component_info.get('device_id') or '')

            stats = DiskStats(
                total_bytes=usage.total,
                used_bytes=usage.used,
                free_bytes=usage.free,
                percent_used=usage.percent,
                read_count=disk_io.read_count if disk_io else 0,
                write_count=disk_io.write_count if disk_io else 0,
                read_bytes=disk_io.read_bytes if disk_io else 0,
                write_bytes=disk_io.write_bytes if disk_io else 0,
                timestamp=time.time()
            )

            self.disk_stats = stats
            self.last_read_time = current_time
            return stats

        except Exception as e:
            self.logger.error(f"Error reading disk stats: {str(e)}")
            return self.disk_stats

    def get_current_stats(self) -> DiskStats:
        """Get current disk statistics"""
        if not self.is_operational():
            raise RuntimeError("Disk driver is not operational")

        return self._read_disk_stats()

    def get_disk_usage(self) -> float:
        """Get current disk usage percentage"""
        if not self.is_operational():
            raise RuntimeError("Disk driver is not operational")

        return self.get_current_stats().percent_used

    def get_disk_info(self) -> Dict[str, Any]:
        """Get detailed disk information"""
        if not self.is_operational():
            raise RuntimeError("Disk driver is not operational")

        return self.disk_info

    def get_health_status(self) -> Dict[str, Any]:
        """Get disk health status"""
        if not self.is_operational():
            raise RuntimeError("Disk driver is not operational")

        stats = self.get_current_stats()
        health = {
            'status': 'good',
            'space_level': 'normal',
            'io_activity': 'normal',
            'issues': []
        }

        # Analyze disk space
        if stats.percent_used > 95:
            health['space_level'] = 'critical'
            health['issues'].append('disk_space_critical')
        elif stats.percent_used > 90:
            health['space_level'] = 'high'
            health['issues'].append('disk_space_high')
        elif stats.percent_used > 80:
            health['space_level'] = 'medium'

        # Analyze I/O activity (simple heuristic)
        total_io = (stats.read_bytes + stats.write_bytes) / (1024 ** 2)  # MB
        if total_io > 100:  # More than 100 MB I/O
            health['io_activity'] = 'high'

        if health['issues']:
            health['status'] = 'warning' if len(health['issues']) == 1 else 'critical'

        return health

    def read_status(self) -> Dict[str, Any]:
        """Read disk status"""
        if not self.is_operational():
            raise RuntimeError("Disk driver is not operational")

        stats = self.get_current_stats()
        health = self.get_health_status()

        return {
            'status': 'operational',
            'component': self.component_info.get('name'),
            'type': self.component_info.get('component_type'),
            'disk_usage_percent': stats.percent_used,
            'total_space_gb': round(stats.total_bytes / (1024 ** 3), 2),
            'used_space_gb': round(stats.used_bytes / (1024 ** 3), 2),
            'free_space_gb': round(stats.free_bytes / (1024 ** 3), 2),
            'read_bytes': stats.read_bytes,
            'write_bytes': stats.write_bytes,
            'health': health,
            'capabilities': [cap.name for cap in self.capabilities]
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert driver to dictionary with disk-specific data"""
        base_dict = super().to_dict()
        base_dict.update({
            'disk_info': self.disk_info,
            'current_stats': self.disk_stats.to_dict(),
            'driver_type': 'disk'
        })
        return base_dict

    def shutdown(self) -> bool:
        """Shutdown the disk driver"""
        try:
            self.state = self.state.DISABLED
            self.logger.info("Disk driver shutdown successfully")
            return True
        except Exception as e:
            self.set_error(e)
            self.logger.error(f"Failed to shutdown disk driver: {str(e)}")
            return False

def create_disk_driver(component_info: Dict[str, Any]) -> DiskNeuralDriver:
    """Create a disk neural driver instance"""
    return DiskNeuralDriver(component_info)

def main():
    """Test the disk driver"""
    # Example component info
    example_component = {
        'component_type': 'disk',
        'name': 'Main SSD',
        'vendor': 'Samsung',
        'device_id': '/dev/nvme0n1p3',
        'capabilities': ['storage', 'persistent'],
        'driver': 'ext4'
    }

    print("Creating disk neural driver...")
    driver = create_disk_driver(example_component)

    print(f"Driver metadata: {driver.get_metadata()}")
    print(f"Driver capabilities: {[cap.name for cap in driver.get_capabilities()]}")

    print("Initializing driver...")
    if driver.initialize():
        print("Driver initialized successfully")
        print(f"Driver state: {driver.get_state()}")

        # Test disk monitoring
        stats = driver.get_current_stats()
        print(f"\nDisk Statistics:")
        print(f"  Total: {round(stats.total_bytes / (1024 ** 3), 2)} GB")
        print(f"  Used: {round(stats.used_bytes / (1024 ** 3), 2)} GB ({stats.percent_used:.1f}%)")
        print(f"  Free: {round(stats.free_bytes / (1024 ** 3), 2)} GB")
        print(f"  Read: {round(stats.read_bytes / (1024 ** 2), 2)} MB")
        print(f"  Write: {round(stats.write_bytes / (1024 ** 2), 2)} MB")

        # Test health status
        health = driver.get_health_status()
        print(f"\nDisk Health:")
        print(f"  Status: {health['status']}")
        print(f"  Space Level: {health['space_level']}")
        print(f"  I/O Activity: {health['io_activity']}")
        if health['issues']:
            print(f"  Issues: {health['issues']}")

        # Test full status
        status = driver.read_status()
        print(f"\nFull Disk Status:")
        print(f"  Component: {status['component']}")
        print(f"  Disk Usage: {status['disk_usage_percent']}%")
        print(f"  Health: {status['health']['status']}")

        # Shutdown
        print("\nShutting down driver...")
        driver.shutdown()
    else:
        print("Failed to initialize driver")

if __name__ == '__main__':
    main()