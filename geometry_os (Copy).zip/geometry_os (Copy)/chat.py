#!/usr/bin/env python3
import asyncio
import sys
import os
import argparse
import time

# Add src to path so we can import internal modules
sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

try:
    from lm_studio.integration import LMStudioIntegration
except ImportError:
    pass

# Import Holographic Cortex (Local GGUF)
try:
    from holographic_llm import HolographicCortex
    HAS_HOLO = True
except ImportError:
    HAS_HOLO = False

async def main():
    parser = argparse.ArgumentParser(description="Geometry OS Intelligence Shell")
    parser.add_argument("--model", type=str, help="Specific model ID/Name to use")
    parser.add_argument("--list", action="store_true", help="List available models")
    parser.add_argument("--holo", action="store_true", help="Use local Holographic Engine (GGUF)")
    parser.add_argument("--db", default="ghost_daemon_knowledge.db", help="Path to Nexus DB (for Holo mode)")
    args = parser.parse_args()

    # --- Mode Selection ---
    if args.holo:
        if not HAS_HOLO:
            print("❌ Holographic Engine not available. (Check dependencies)")
            return
        await run_holographic_session(args.model, args.db)
    else:
        await run_api_session(args.model, args.list)

async def run_holographic_session(model_name, db_path):
    """Run a chat session using local GGUF models"""
    if not model_name:
        print("❌ For Holographic mode, you must specify a model name (e.g., --model 'DeepSeek-Coder-V2...')")
        print("   (Tip: Check your ingested models in the Nexus)")
        return

    print(f"\n🌌 Initializing Holographic Cortex...")
    print(f"   Target: {model_name}")
    print(f"   Nexus:  {db_path}")

    try:
        # Initialize Cortex (Loads GGUF)
        cortex = HolographicCortex(model_name, db_path=db_path)
        
        print(f"\n🧠 \033[1;35mHolographic Cortex Online\033[0m")
        print("Type 'exit' or 'quit' to leave.\n")

        history = []
        
        while True:
            try:
                user_input = input("\033[1;36mYou > \033[0m")
                if user_input.lower() in ["exit", "quit"]:
                    break
                
                print("\033[1;33mThinking...\033[0m", end="\r")
                
                # Context Management (Simple append for now)
                # Note: HolographicCortex.think() expects a prompt string
                full_prompt = "\n".join(history + [f"User: {user_input}", "Assistant:"])
                
                # Inference
                # Run in thread executor to avoid blocking asyncio loop (since llama.cpp is blocking)
                response = await asyncio.to_thread(cortex.think, full_prompt)
                
                print(f"\033[1;35mCortex > \033[0m{response}\n")
                
                # Update history (keep small context for CLI)
                history.append(f"User: {user_input}")
                history.append(f"Assistant: {response}")
                if len(history) > 6:
                    history = history[-6:]

            except KeyboardInterrupt:
                print("\nExiting...")
                break
            except Exception as e:
                print(f"❌ Error: {e}")
                
    except Exception as e:
        print(f"❌ critical Failure: {e}")

async def run_api_session(model_id, list_models):
    """Run a chat session using LM Studio API"""
    try:
        lms = LMStudioIntegration()
    except Exception as e:
        print(f"❌ Could not connect to API Integration: {e}")
        return

    if list_models:
        print("🔍 Scanning API Models...")
        models = await lms.list_models()
        print("\nAvailable API Models:")
        for m in models:
            print(f" - {m['id']} (Context: {m.get('context_length', '?')})")
        return

    if not model_id:
        print("🔍 Auto-detecting best API model...")
        model_id = await lms.get_loaded_model()
    
    if not model_id:
        print("❌ No API models found. Is LM Studio running? (Try --holo for local)")
        return

    print(f"\n☁️  Connected to API: \033[1;32m{model_id}\033[0m")
    print("Type 'exit' or 'quit' to leave.\n")

    history = []

    while True:
        try:
            user_input = input("\033[1;36mYou > \033[0m")
            if user_input.lower() in ["exit", "quit"]:
                break
            
            prompt = "\n".join(history + [f"User: {user_input}", "System:"])
            print("\033[1;33mThinking...\033[0m", end="\r")
            
            response = await lms.generate(
                model=model_id,
                prompt=prompt,
                max_tokens=800,
                stop=["User:"]
            )
            
            content = response.get("content", "[No response]")
            history.append(f"User: {user_input}")
            history.append(f"System: {content}")
            if len(history) > 10:
                history = history[-10:]

            print(f"\033[1;32mDevice > \033[0m{content}\n")

        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")
