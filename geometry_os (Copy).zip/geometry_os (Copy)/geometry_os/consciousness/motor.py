
"""
The Motor Cortex (Agency Interface)
Safe execution of intent.
"""
import os
import subprocess
import sys
from pathlib import Path
from typing import Dict, Any, Optional

class MotorCortex:
    def __init__(self):
        pass

    def execute_volition(self, volition_text: str):
        """
        Parses the volition text and triggers actions.
        For now, this is a stub that logs the intent.
        """
        print(f"🦾 MOTOR CORTEX: Received Volition -> {volition_text[:100]}...")

        # Simple extraction logic (placeholder)
        if "optimize" in volition_text.lower():
            print("   -> Action: Triggering Optimization Routine (Simulated)")
        elif "learn" in volition_text.lower():
            print("   -> Action: Triggering Knowledge Acquisition (Simulated)")
        elif "sleep" in volition_text.lower():
            print("   -> Action: Adjusting sleep cycles (Simulated)")

        return "Volition Acknowledged"

    def execute_code(self, code: str, language: str = "python", working_dir: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute code using the Motor Cortex execution capabilities.
        This provides the integration point for CodeProver to use Motor Cortex for execution.
        """
        try:
            # Create a temporary file for the code
            if working_dir is None:
                working_dir = str(Path(tempfile.gettempdir()) / "motor_cortex_execution")
                os.makedirs(working_dir, exist_ok=True)

            if language == "python":
                file_path = Path(working_dir) / "motor_execution.py"
                with open(file_path, 'w') as f:
                    f.write(code)

                result = subprocess.run(
                    [sys.executable, str(file_path)],
                    cwd=working_dir,
                    capture_output=True,
                    text=True,
                    timeout=60
                )

                return {
                    "success": result.returncode == 0,
                    "error": result.stderr if result.returncode != 0 else None,
                    "output": result.stdout,
                    "returncode": result.returncode,
                    "execution_method": "motor_cortex"
                }

            else:
                return {
                    "success": False,
                    "error": f"Unsupported language for Motor Cortex execution: {language}",
                    "output": "",
                    "returncode": 1,
                    "execution_method": "motor_cortex"
                }

        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "Execution timed out",
                "output": "",
                "returncode": -1,
                "execution_method": "motor_cortex"
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "output": "",
                "returncode": -1,
                "execution_method": "motor_cortex"
            }
