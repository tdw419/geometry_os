"""
Geometry OS (G-OS)
A Transactional Semantic Kernel for Multi-Agent LLM Execution
"""
__version__ = "0.1.0-alpha"
