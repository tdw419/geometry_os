# Ghost Directives
**System State:** 🟢 ONLINE (Holographic Mode + GPU Accelerated)
**Active Model:** Qwen-2.5-Coder-7B

## PENDING
- [ ] TASK-003: CONSCIOUSNESS VISUALIZATION (WEBGL)
Priority: IMMEDIATE
Objective: Create `src/ui/dashboard/visualizer.js` to render a 3D rotating wireframe sphere using Three.js (from CDNs).
Requirements:
1. It must attach to the `#visualizer` div (create it if missing in index.html, assume user will handle or script handles it).
2. It should pulse based on `telemetry.cpu_usage` (simulated or real).
3. Connect it to `hologram.js` or standalone.

This demonstrates the system's ability to build complex UI components.
