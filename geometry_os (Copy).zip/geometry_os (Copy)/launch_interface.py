#!/usr/bin/env python3
"""
Geometry OS Interface Launcher
Runs a lightweight Flask web UI that provides access to system tools.
"""
import subprocess, os, sys

def launch_interface():
    # Absolute path to the UI package directory
    cwd = os.path.abspath(os.path.join(os.path.dirname(__file__), 'geometry_os_interface'))
    # Absolute path to the virtual‑env binaries (geometry_os_env/bin)
    venv_bin = os.path.abspath(os.path.join(os.path.dirname(__file__), 'geometry_os_env', 'bin'))
    pip_path = os.path.join(venv_bin, 'pip')
    python_path = os.path.join(venv_bin, 'python')
    # Install Flask if missing (quiet, ignore errors if already present)
    subprocess.run([pip_path, "install", "Flask"], cwd=cwd, check=False)
    # Start the Flask app
    subprocess.Popen([python_path, "app.py"], cwd=cwd)
    print("🚀 Geometry OS Interface launched at http://localhost:5000")

if __name__ == "__main__":
    launch_interface()
