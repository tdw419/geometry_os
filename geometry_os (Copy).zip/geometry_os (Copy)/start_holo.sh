#!/bin/bash
# Start Geometry OS with Holographic Cortex (Local Intelligence)

# 1. Activate Environment (Native Drivers)
source geometry_os_env/bin/activate

# 2. Set Holographic Flag
export USE_HOLOGRAPHIC=true
export HOLOGRAPHIC_MODEL="phi-4" # Can be changed to Qwen, DeepSeek, etc.

# 3. Launch Daemon
echo "🌌 Launching Geometry OS (Holographic Mode: $HOLOGRAPHIC_MODEL)..."
python3 src/main.py
