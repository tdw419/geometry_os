import sqlite3
import sys

db_path = "/home/jericho/zion/projects/geometry_os/geometry_os/ctrm_llm_os.db"
target_id = "qwen2.5-coder-7b-instruct-q4_k_m"

print(f"Probe: Connecting to {db_path}...")
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row

print(f"Probe: Querying for '{target_id}'...")
cursor = conn.execute("SELECT * FROM nodes WHERE id=?", (target_id,))
row = cursor.fetchone()

if row:
    print("✅ FOUND!")
    print(dict(row))
else:
    print("❌ NOT FOUND")
    
    # Dump all
    print("\n--- DUMPING TABLE ---")
    cursor = conn.execute("SELECT * FROM nodes")
    for r in cursor:
        print(dict(r))
