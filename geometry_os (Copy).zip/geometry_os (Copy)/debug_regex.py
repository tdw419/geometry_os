import re
import os

content = """
# Ghost Directives
**System State:** 🟢 ONLINE (Holographic Mode)
**Active Model:** Qwen-2.5-Coder-7B

## TASK-001: HOLOGRAPHIC DIAGNOSTIC TOOL (RETRY)
Priority: IMMEDIATE
Objective: Create a Python component `src/system/holo_diagnostic.py` that allows the OS to test its own neural latency.
Requirements:
1. Define a class `HoloDiagnostic`.
"""

pattern = r"## TASK-.*: (.+)\nPriority: IMMEDIATE\nObjective: (.+)"

print(f"Testing Pattern: {pattern}")
match = re.search(pattern, content)

if match:
    print("✅ Match Found!")
    print(f"Group 1: {match.group(1)}")
    print(f"Group 2: {match.group(2)}")
else:
    print("❌ No match found.")
    
# Debugging: show what lines look like
lines = content.split('\n')
for i, line in enumerate(lines):
    if "TASK" in line:
        print(f"Line {i}: {line!r}")
    if "Priority" in line:
        print(f"Line {i}: {line!r}")
