import sys
import os
import asyncio
import re

# Mock the environment to load the class
sys.path.append(os.getcwd())

from src.evolution.evolution_daemon import TokenAwareEvolutionDaemon

# Mock dependencies
class MockCTRM: pass
class MockTokens: pass
class MockLM: pass

async def test_read():
    daemon = TokenAwareEvolutionDaemon(MockCTRM(), MockTokens(), MockLM())
    
    # Manually invoke the method logic to debug path (since I can't easily access the private method instance directly if it relies on self state, but this method is mostly stateless regarding file reading)
    
    # Replicating the logic from the patched file to verify PATH resolution
    directives_path = os.path.join(os.path.dirname(os.path.abspath("src/evolution/evolution_daemon.py")), "../../GHOST_DIRECTIVES.md")
    print(f"Testing Path: {directives_path}")
    print(f"Exists: {os.path.exists(directives_path)}")
    
    try:
        result = await daemon._read_directives_prioritized()
        print(f"Result: {result}")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_read())
