#!/usr/bin/env python3
"""
HAL Integration Verification Script
Verifies that the Hardware Abstraction Layer is properly integrated with the OS daemon
"""

import asyncio
import json
import sys
import os

# Add src to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from hardware.hal import create_hal, HALState
from hardware.discovery import discover_hardware
from src.main import CTRMLLMOSDaemon

def verify_hal_integration():
    """Verify HAL integration with the OS daemon"""
    print("🔌 Starting HAL Integration Verification...")

    # Test 1: Hardware Discovery
    print("\n1. Testing Hardware Discovery...")
    try:
        hardware_data = discover_hardware()
        print(f"✅ Hardware Discovery: {len(hardware_data['components'])} components found")
        print(f"   System: {hardware_data['system_info']['os']} {hardware_data['system_info']['architecture']}")
    except Exception as e:
        print(f"❌ Hardware Discovery Failed: {e}")
        return False

    # Test 2: HAL Creation
    print("\n2. Testing HAL Creation...")
    try:
        hal = create_hal()
        hal_status = hal.get_operational_status()
        print(f"✅ HAL Created: {hal_status['state']} state")
        print(f"   Operational Devices: {hal_status['operational_devices']}")
        print(f"   Total Devices: {hal_status['total_devices']}")
        print(f"   Error Count: {hal_status['error_count']}")
    except Exception as e:
        print(f"❌ HAL Creation Failed: {e}")
        return False

    # Test 3: System Summary
    print("\n3. Testing System Summary...")
    try:
        system_summary = hal.get_system_summary()
        device_types = system_summary['device_types']
        print(f"✅ System Summary Generated")
        print(f"   Device Types: {device_types}")
        print(f"   Total Components: {system_summary['device_count']}")
    except Exception as e:
        print(f"❌ System Summary Failed: {e}")
        return False

    # Test 4: Daemon Integration
    print("\n4. Testing Daemon Integration...")
    try:
        async def test_daemon_integration():
            daemon = CTRMLLMOSDaemon()
            await daemon.initialize()

            if daemon.hal is None:
                print("❌ HAL not initialized in daemon")
                return False

            hal_status = daemon.hal.get_operational_status()
            print(f"✅ Daemon Integration: HAL operational in daemon")
            print(f"   Daemon HAL State: {hal_status['state']}")
            print(f"   Daemon Devices: {hal_status['operational_devices']}")

            # Check if HAL state was logged to CTRM
            try:
                ctrm_truths = await daemon.ctrm.find_truths_by_context("system_startup", limit=1)
                if ctrm_truths:
                    print(f"✅ CTRM Integration: HAL state logged to CTRM")
                    print(f"   Truth: {ctrm_truths[0]['statement'][:80]}...")
                else:
                    print("⚠️  CTRM Integration: No HAL startup truth found")
            except Exception as e:
                print(f"ℹ️  CTRM Integration: Method not available, but HAL is operational: {e}")

            return True

        result = asyncio.run(test_daemon_integration())
        if not result:
            return False

    except Exception as e:
        print(f"❌ Daemon Integration Failed: {e}")
        return False

    # Test 5: Health Monitoring
    print("\n5. Testing Health Monitoring...")
    try:
        from hardware.hal import HALMonitor
        monitor = HALMonitor(hal)
        health_report = monitor.check_health()

        print(f"✅ Health Monitoring: {health_report['overall_health']} health")
        if health_report['issues']:
            print(f"   Issues Found: {health_report['issues']}")
        else:
            print("   No issues detected")
    except Exception as e:
        print(f"❌ Health Monitoring Failed: {e}")
        return False

    print("\n🎉 HAL Integration Verification Complete!")
    print("✅ All tests passed - Hardware Abstraction Layer is fully integrated")

    return True

def main():
    """Main verification function"""
    print("🔍 HAL Integration Verification Tool")
    print("=" * 50)

    success = verify_hal_integration()

    if success:
        print("\n🎉 VERIFICATION SUCCESS")
        print("The Hardware Abstraction Layer is properly integrated with Geometry OS")
        print("The system now has full hardware awareness and control capabilities")
    else:
        print("\n❌ VERIFICATION FAILED")
        print("Some components failed verification")
        sys.exit(1)

if __name__ == "__main__":
    main()