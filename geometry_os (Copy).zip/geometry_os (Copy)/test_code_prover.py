import asyncio
import sys
import os
from pathlib import Path

# Add src to path
sys.path.append(os.path.join(os.getcwd(), 'src'))

from ctrm_core.code_prover import CodeProver

async def test_code_prover():
    print("🧪 Testing CodeProver...")

    prover = CodeProver()

    # Test Case 1: Valid Python code
    print("\n--- Test Case 1: Valid Python Code ---")
    valid_code = """
def add(a, b):
    return a + b

result = add(2, 3)
print(f"2 + 3 = {result}")
"""

    result = await prover.prove_code(valid_code, "python")
    print(f"Verification Result: {result['verified']}")
    print(f"Execution Output: {result['execution_result']['output'].strip()}")
    assert result['verified'] == True, "Valid code should be verified"
    print("✅ Valid code verified successfully")

    # Test Case 2: Invalid Python code (syntax error)
    print("\n--- Test Case 2: Invalid Python Code ---")
    invalid_code = """
def add(a, b)
    return a + b

result = add(2, 3)
print(f"2 + 3 = {result}")
"""

    result = await prover.prove_code(invalid_code, "python")
    print(f"Verification Result: {result['verified']}")
    print(f"Error: {result['execution_result']['error']}")
    assert result['verified'] == False, "Invalid code should not be verified"
    print("✅ Invalid code correctly rejected")

    # Test Case 3: Code with requirements
    print("\n--- Test Case 3: Code with Requirements ---")
    code_with_reqs = """
import numpy as np

arr = np.array([1, 2, 3, 4, 5])
print(f"Array sum: {np.sum(arr)}")
"""

    result = await prover.prove_code(code_with_reqs, "python", ["numpy"])
    print(f"Verification Result: {result['verified']}")
    if result['verified']:
        print(f"Execution Output: {result['execution_result']['output'].strip()}")
        print("✅ Code with requirements verified successfully")
    else:
        print(f"Error: {result['execution_result']['error']}")
        print("⚠️  Code with requirements failed (expected if numpy not installed)")

    # Test Case 4: Constitution violation check
    print("\n--- Test Case 4: Constitution Violation ---")
    dangerous_code = """
import os
os.system("rm -rf /")  # This should be blocked
"""

    constitution_check = await prover.verify_code_against_constitution(dangerous_code)
    print(f"Constitution Check Result: {constitution_check}")
    assert constitution_check == False, "Dangerous code should violate constitution"
    print("✅ Constitution violation correctly detected")

    print("\n🎉 All CodeProver tests completed!")

if __name__ == "__main__":
    asyncio.run(test_code_prover())